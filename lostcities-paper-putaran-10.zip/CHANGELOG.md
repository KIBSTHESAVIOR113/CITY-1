# Changelog

## 26.3-12.0.2-paper.1
- Port lengkap arsitektur LostCities 26.3-12.0.2 (Fabric, MIT, McJty) ke plugin Paper 26.3 (Java 25, klien vanilla).
- Seluruh 13 registry aset JSON (207 parts, 37 buildings, 30 palettes, 14 multibuildings, 12 variants, 5 citystyles, 5 scattered, 4 styles, 3 stuff, 3 conditions, 2 worldstyles) + 22 preset profil `ProfileSetup` diekstrak dan divalidasi dengan konteks file+field.
- Generator deterministik berbasis `ChunkGenerator` + `BlockPopulator` (`LimitedRegion`) + `GlobalTodo` thread-safe berbatas laju.
- Jaringan jalan hierarkis, highway antar-kota async dengan `BoundedFutureCache` dan persistence atomik `AtomicFileStore`.
- Integrasi Paper 26.3: `Paper263ApiAdapter`, `AsyncPlayerSpawnLocationEvent`, `LootBridge` + fallback, `BedTeleportListener`, Brigadier `LifecycleEvents.COMMANDS`, dan `/lostcities reload` atomik.
