/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

import mcjty.lostcities.paper.assets.AssetLoader;
import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.plan.ChunkPlanner;
import mcjty.lostcities.paper.util.PathSecurity;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.*;

class CoreWorldgenDeterminismTest {

    private static final class MemorySurface implements BlockSurface {
        private final int minY;
        private final int maxY;
        private final int cx;
        private final int cz;
        final Map<Long, String> blocks = new TreeMap<>();

        MemorySurface(int cx, int cz, int minY, int maxY) {
            this.cx = cx;
            this.cz = cz;
            this.minY = minY;
            this.maxY = maxY;
        }

        @Override public int minY() { return minY; }
        @Override public int maxY() { return maxY; }
        @Override public boolean isInBounds(int x, int y, int z) {
            return (x >> 4) == cx && (z >> 4) == cz && y >= minY && y < maxY;
        }
        @Override public String getBlockId(int x, int y, int z) {
            return blocks.getOrDefault(ChunkDriver.packPos(x, y, z), y <= 64 ? "minecraft:stone" : "minecraft:air");
        }
        @Override public void setBlockId(int x, int y, int z, String blockId) {
            blocks.put(ChunkDriver.packPos(x, y, z), blockId);
        }
    }

    @Test
    void hundredChunksInTwoRandomOrdersProduceIdenticalHashes() throws Exception {
        AssetRegistry registry = new AssetLoader(
                Path.of("src/main/resources/data/lostcities/lostcities"),
                PathSecurity.DEFAULT_MAX_JSON_BYTES,
                Logger.getLogger("test")
        ).loadAll();

        LostCityProfile profile = new LostCityProfile("default");
        List<int[]> coords = new ArrayList<>();
        for (int cx = -5; cx < 5; cx++) {
            for (int cz = -5; cz < 5; cz++) {
                coords.add(new int[]{cx, cz});
            }
        }

        List<int[]> orderA = new ArrayList<>(coords);
        Collections.shuffle(orderA, new Random(111L));
        List<int[]> orderB = new ArrayList<>(coords);
        Collections.shuffle(orderB, new Random(999L));

        Map<Long, String> hashesA = runOrder(orderA, 12345L, profile, registry);
        Map<Long, String> hashesB = runOrder(orderB, 12345L, profile, registry);
        assertEquals(hashesA, hashesB, "Chunk block hashes MUST be identical regardless of chunk load order");
    }

    private static Map<Long, String> runOrder(List<int[]> order, long seed, LostCityProfile profile, AssetRegistry registry) throws Exception {
        LostCityTerrainFeature feature = new LostCityTerrainFeature(seed, "lostcities:lostcity", profile);
        ChunkPlanner planner = new ChunkPlanner(4096, 300);
        Map<Long, String> result = new TreeMap<>();
        MessageDigest sha = MessageDigest.getInstance("SHA-256");

        for (int[] c : order) {
            MemorySurface surface = new MemorySurface(c[0], c[1], 0, 256);
            feature.generateChunk(surface, c[0], c[1], registry, planner, null);
            sha.reset();
            for (Map.Entry<Long, String> e : surface.blocks.entrySet()) {
                sha.update(Long.toString(e.getKey()).getBytes(StandardCharsets.UTF_8));
                sha.update((byte) '=');
                sha.update(e.getValue().getBytes(StandardCharsets.UTF_8));
                sha.update((byte) ';');
            }
            result.put(ChunkCoord.pack(c[0], c[1]), HexFormat.of().formatHex(sha.digest()));
        }
        return result;
    }
}
