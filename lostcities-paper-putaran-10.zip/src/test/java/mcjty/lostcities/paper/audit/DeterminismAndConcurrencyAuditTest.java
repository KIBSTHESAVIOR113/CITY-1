/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.audit;

import mcjty.lostcities.paper.assets.AssetLoader;
import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.BlockSurface;
import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.core.ChunkDriver;
import mcjty.lostcities.paper.core.LostCityTerrainFeature;
import mcjty.lostcities.paper.core.plan.ChunkPlanner;
import mcjty.lostcities.paper.util.PathSecurity;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Putaran 7 Audit Harness: proves 1000-chunk order independence and thread-count independence.
 */
class DeterminismAndConcurrencyAuditTest {

    private static final class GridSurface implements BlockSurface {
        private final int cx, cz, minY, maxY;
        final Map<Long, String> blocks = new TreeMap<>();
        GridSurface(int cx, int cz, int minY, int maxY) { this.cx = cx; this.cz = cz; this.minY = minY; this.maxY = maxY; }
        @Override public int minY() { return minY; }
        @Override public int maxY() { return maxY; }
        @Override public boolean isInBounds(int x, int y, int z) { return (x >> 4) == cx && (z >> 4) == cz && y >= minY && y < maxY; }
        @Override public String getBlockId(int x, int y, int z) { return blocks.getOrDefault(ChunkDriver.packPos(x, y, z), y <= 64 ? "minecraft:stone" : "minecraft:air"); }
        @Override public void setBlockId(int x, int y, int z, String blockId) { blocks.put(ChunkDriver.packPos(x, y, z), blockId); }
    }

    @Test
    void thousandChunksIdenticalAcrossTwoRandomOrdersAndFourThreads() throws Exception {
        AssetRegistry registry = new AssetLoader(
                Path.of("src/main/resources/data/lostcities/lostcities"),
                PathSecurity.DEFAULT_MAX_JSON_BYTES,
                Logger.getLogger("audit")
        ).loadAll();
        LostCityProfile profile = new LostCityProfile("default");

        List<int[]> coords = new ArrayList<>(1000);
        for (int cx = -16; cx < 16; cx++) {
            for (int cz = -16; cz < 16; cz++) {
                if (coords.size() < 1000) coords.add(new int[]{cx, cz});
            }
        }
        assertEquals(1000, coords.size());

        List<int[]> order1 = new ArrayList<>(coords);
        Collections.shuffle(order1, new Random(42L));
        List<int[]> order2 = new ArrayList<>(coords);
        Collections.shuffle(order2, new Random(84L));

        Map<Long, String> singleThreadA = runParallel(order1, 1, 777L, profile, registry);
        Map<Long, String> multiThreadB = runParallel(order2, 4, 777L, profile, registry);
        assertEquals(singleThreadA, multiThreadB, "1000-chunk hashes MUST be identical across chunk orders and thread counts");
    }

    private static Map<Long, String> runParallel(List<int[]> coords, int threads, long seed,
                                                 LostCityProfile profile, AssetRegistry registry) throws Exception {
        LostCityTerrainFeature feature = new LostCityTerrainFeature(seed, "lostcities:lostcity", profile);
        ChunkPlanner planner = new ChunkPlanner(4096, 300);
        ConcurrentHashMap<Long, String> out = new ConcurrentHashMap<>();
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        try {
            List<Future<?>> futures = new ArrayList<>();
            for (int[] c : coords) {
                futures.add(pool.submit(() -> {
                    try {
                        GridSurface s = new GridSurface(c[0], c[1], 0, 256);
                        feature.generateChunk(s, c[0], c[1], registry, planner, null);
                        MessageDigest sha = MessageDigest.getInstance("SHA-256");
                        for (Map.Entry<Long, String> e : s.blocks.entrySet()) {
                            sha.update(Long.toString(e.getKey()).getBytes(StandardCharsets.UTF_8));
                            sha.update((byte) '=');
                            sha.update(e.getValue().getBytes(StandardCharsets.UTF_8));
                        }
                        out.put(ChunkCoord.pack(c[0], c[1]), HexFormat.of().formatHex(sha.digest()));
                    } catch (Exception ex) {
                        throw new RuntimeException(ex);
                    }
                }));
            }
            for (Future<?> f : futures) {
                f.get();
            }
        } finally {
            pool.shutdownNow();
        }
        return new TreeMap<>(out);
    }
}
