/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.network;

import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.highway.HighwayModels.*;
import mcjty.lostcities.paper.core.highway.HighwayPlanningService;
import mcjty.lostcities.paper.core.highway.HighwayStore;
import mcjty.lostcities.paper.core.highway.IntercityHighwayPlanner;
import mcjty.lostcities.paper.core.street.HierarchicalStreetPlanner;
import mcjty.lostcities.paper.core.street.PlannedRoadType;
import mcjty.lostcities.paper.core.street.PlannedStreetInfo;
import mcjty.lostcities.paper.persistence.AtomicFileStore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.*;

class NetworkAndPersistenceTest {

    @Test
    void primaryStreetsConnectContinuouslyAcrossChunks() {
        LostCityProfile profile = new LostCityProfile("default");
        HierarchicalStreetPlanner planner = new HierarchicalStreetPlanner(12345L, "lostcities:lostcity", profile);
        // Chunk X=0 is always a forced primary road line (0 % forceEvery == 0)
        PlannedStreetInfo s0 = planner.getStreetInfo(0, 0);
        PlannedStreetInfo s1 = planner.getStreetInfo(0, 1);
        assertEquals(PlannedRoadType.PRIMARY, s0.roadType());
        assertEquals(PlannedRoadType.PRIMARY, s1.roadType());
        assertTrue(s0.south());
        assertTrue(s1.north());
    }

    @Test
    void highwayPersistenceSurvivesRestartAndRecoversFromCorruption(@TempDir Path tmp) throws Exception {
        AtomicFileStore fs = new AtomicFileStore(tmp, 2_097_152L, Logger.getLogger("test"));
        HighwayStore store1 = new HighwayStore(fs, 99999L);
        HubKey key = new HubKey(0, 0);
        HighwayHub hub = new HighwayHub(key, 16, 16, 850, 0);
        store1.store(key, Optional.of(hub));
        store1.flushIfDirty();

        // Reload cleanly
        HighwayStore store2 = new HighwayStore(fs, 99999L);
        assertEquals(Optional.of(Optional.of(hub)), store2.lookup(key));

        // Simulate mid-write crash corruption
        Files.writeString(tmp.resolve("highways.json"), "{"formatVersion": 2, "data": { TRUNCATED");
        HighwayStore store3 = new HighwayStore(fs, 99999L);
        assertTrue(store3.lookup(key).isEmpty(), "Corrupted store must safely fall back to empty/regenerated state");

        // Verify planner + bounded service still produce deterministic hub
        LostCityProfile profile = new LostCityProfile("default");
        IntercityHighwayPlanner planner = new IntercityHighwayPlanner(12345L, "lostcities:lostcity", profile, store3);
        try (HighwayPlanningService service = new HighwayPlanningService(planner, 64, 64, 2)) {
            assertNotNull(service.getHighwayInfo(0, 0));
            assertTrue(service.hubCacheSize() <= 64);
        }
    }
}
