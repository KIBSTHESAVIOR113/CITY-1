/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.config;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.junit.jupiter.api.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class LostCityProfileParityTest {

    @Test
    void defaultValuesMatchLostCities263Source() {
        LostCityProfile p = new LostCityProfile("default");
        assertEquals("default", p.getName());
        assertTrue(p.isPublic());
        assertEquals("standard", p.getWorldStyle());
        assertEquals("minecraft:water", p.liquidBlock);
        assertEquals("minecraft:stone", p.baseBlock);
        assertEquals(71, p.groundLevel);
        assertEquals(-1, p.seaLevel);
        assertEquals(1, p.bedrockLayer);
        assertEquals(0.3f, p.buildingChance, 1e-6f);
        assertEquals(0, p.buildingMinFloors);
        assertEquals(8, p.buildingMaxFloors);
        assertEquals(0, p.buildingMinCellars);
        assertEquals(3, p.buildingMaxCellars);
        assertEquals(0.05f, p.ruinChance, 1e-6f);
        assertEquals(0.009f, p.vineChance, 1e-6f);
        assertEquals(0.01, p.cityChance, 1e-9);
        assertEquals(50, p.cityMinRadius);
        assertEquals(128, p.cityMaxRadius);
        assertEquals(0.2f, p.cityThreshold, 1e-6f);
        assertEquals(StreetGenerationMode.HIERARCHICAL_GRID_V1, p.streetGenerationMode);
        assertEquals(HighwayGenerationMode.INTERCITY_NETWORK_V1, p.highwayGenerationMode);
        assertEquals(MultiBuildingStreetConflict.OVERRIDE_MINOR, p.multiBuildingStreetConflict);
        assertEquals(LandscapeType.DEFAULT, p.landscapeType);
        assertEquals(10, p.railwaySpacingNorthSouth);
        assertEquals(10, p.railwaySpacingEastWest);
        assertEquals(200, p.spawnCheckRadius);
        assertEquals(20000, p.spawnCheckAttempts);
    }

    @Test
    void outOfRangeValuesFallbackToDefaultWithWarning() {
        LostCityProfile p = new LostCityProfile("custom");
        JsonObject obj = JsonParser.parseString("{"groundLevel": 999, "buildingChance": 5.0}").getAsJsonObject();
        List<String> warnings = p.applyJsonAndValidate(obj);
        assertEquals(2, warnings.size());
        assertEquals(71, p.groundLevel);
        assertEquals(0.3f, p.buildingChance, 1e-6f);
    }

    @Test
    void all22BuiltinPresetsExistAndParseCleanly() throws Exception {
        Path presetsDir = Path.of("src/main/resources/profiles");
        assertEquals(22, ConfigLoader.BUILTIN_PRESETS.size());
        for (String preset : ConfigLoader.BUILTIN_PRESETS) {
            Path file = presetsDir.resolve(preset + ".json");
            assertTrue(Files.exists(file), "Missing preset file: " + file);
            JsonObject obj = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            LostCityProfile p = new LostCityProfile(preset);
            List<String> warnings = p.applyJsonAndValidate(obj);
            assertTrue(warnings.isEmpty(), "Preset " + preset + " produced warnings: " + warnings);
        }
    }
}
