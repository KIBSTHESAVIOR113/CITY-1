/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper;

import io.papermc.paper.plugin.bootstrap.BootstrapContext;
import io.papermc.paper.plugin.bootstrap.PluginBootstrap;
import io.papermc.paper.plugin.lifecycle.event.types.LifecycleEvents;

import java.net.URI;
import java.util.Objects;

/**
 * Paper {@link PluginBootstrap} registering the built-in LostCities datapack
 * ({@code dimension_type/lostcity.json} with min_y=0/height=256 and chest loot tables)
 * before worlds load.
 */
public final class LostCitiesBootstrap implements PluginBootstrap {

    @Override
    public void bootstrap(BootstrapContext context) {
        // [PERLU-VERIFIKASI: LifecycleEvents.DATAPACK_DISCOVERY behavior for custom dimension_type in Paper 26.3]
        context.getLifecycleManager().registerEventHandler(LifecycleEvents.DATAPACK_DISCOVERY.newHandler(event -> {
            try {
                URI uri = Objects.requireNonNull(
                        LostCitiesBootstrap.class.getResource("/datapack_builtin"),
                        "Missing /datapack_builtin resource"
                ).toURI();
                event.registrar().discoverPack(uri, "lostcities_builtin");
            } catch (Throwable ex) {
                context.getLogger().warn("Built-in LostCities datapack discovery skipped (adaptive fallback active): " + ex.getMessage());
            }
        }));
    }
}
