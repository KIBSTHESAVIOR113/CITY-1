/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.config;

import java.util.Locale;

public enum MultiBuildingStreetConflict {
    BLOCK_ALL,
    OVERRIDE_MINOR,
    OVERRIDE_ALL;

    public static MultiBuildingStreetConflict byName(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("MultiBuildingStreetConflict cannot be blank");
        }
        return valueOf(name.trim().toUpperCase(Locale.ROOT));
    }
}
