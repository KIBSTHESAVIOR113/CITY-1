/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.config;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public enum BiomeSelectionStrategy {
    ORIGINAL("original"),
    RANDOMIZED("randomized"),
    VARIED("varied");

    private final String id;
    private static final Map<String, BiomeSelectionStrategy> BY_NAME = new LinkedHashMap<>();

    static {
        for (BiomeSelectionStrategy strategy : values()) {
            BY_NAME.put(strategy.id, strategy);
        }
    }

    BiomeSelectionStrategy(String id) {
        this.id = id;
    }

    public String getName() {
        return id;
    }

    public static BiomeSelectionStrategy getTypeByName(String name) {
        if (name == null) {
            return null;
        }
        return BY_NAME.get(name.trim().toLowerCase(Locale.ROOT));
    }
}
