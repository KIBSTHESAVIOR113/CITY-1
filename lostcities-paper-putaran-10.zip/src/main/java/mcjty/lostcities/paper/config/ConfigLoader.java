/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import mcjty.lostcities.paper.util.PathSecurity;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Logger;
import java.util.stream.Stream;

/**
 * Extracts built-in profile presets on first startup and loads/saves validated
 * {@link LostCityProfile} instances from {@code plugins/LostCities/profiles/*.json}.
 */
public final class ConfigLoader {

    public static final List<String> BUILTIN_PRESETS = List.of(
            "ancient", "atlantis", "bio_wasteland", "biosphere", "biosphere_caves",
            "cavern", "chisel", "customized", "default", "floating", "largecities",
            "nodamage", "onlycities", "rarecities", "realistic", "safe", "space",
            "tallbuildings", "void_outside", "wasteland", "water_empty", "waterbubbles"
    );

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final Path profilesDir;
    private final long maxJsonBytes;
    private final Logger logger;

    public ConfigLoader(Path dataFolder, long maxJsonBytes, Logger logger) {
        this.profilesDir = dataFolder.resolve("profiles").toAbsolutePath().normalize();
        this.maxJsonBytes = maxJsonBytes;
        this.logger = logger;
    }

    /**
     * Copies all 22 built-in preset JSON files from plugin resources if not already present.
     */
    public void ensureDefaultProfilesExtracted(ClassLoader resourceLoader) {
        try {
            Files.createDirectories(profilesDir);
        } catch (IOException ex) {
            logger.warning("Failed to create profiles directory: " + ex.getMessage());
            return;
        }
        for (String preset : BUILTIN_PRESETS) {
            Path target = PathSecurity.resolveInside(profilesDir, preset + ".json");
            if (Files.exists(target)) {
                continue;
            }
            String resourcePath = "profiles/" + preset + ".json";
            try (InputStream in = resourceLoader.getResourceAsStream(resourcePath)) {
                if (in != null) {
                    Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
                }
            } catch (IOException ex) {
                logger.warning("Failed to extract built-in profile '" + preset + "': " + ex.getMessage());
            }
        }
    }

    /**
     * Loads and validates all profile JSON files in deterministic sorted filename order.
     */
    public Map<String, LostCityProfile> loadProfiles() {
        Map<String, LostCityProfile> loaded = new LinkedHashMap<>();
        if (!Files.isDirectory(profilesDir)) {
            loaded.put("default", new LostCityProfile("default"));
            return Collections.unmodifiableMap(loaded);
        }
        List<Path> files;
        try (Stream<Path> stream = Files.list(profilesDir)) {
            files = stream
                    .filter(p -> Files.isRegularFile(p) && p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".json"))
                    .sorted()
                    .toList();
        } catch (IOException ex) {
            logger.warning("Failed to list profiles directory: " + ex.getMessage());
            loaded.put("default", new LostCityProfile("default"));
            return Collections.unmodifiableMap(loaded);
        }

        for (Path file : files) {
            String rawName = file.getFileName().toString();
            String baseName = rawName.substring(0, rawName.length() - 5);
            try {
                String safeName = PathSecurity.validateSafeName(baseName, "profile");
                String json = PathSecurity.readBoundedUtf8(file, maxJsonBytes);
                JsonElement el = JsonParser.parseString(json);
                if (!el.isJsonObject()) {
                    logger.warning("Skipping invalid profile file '" + rawName + "': root element is not a JSON object");
                    continue;
                }
                LostCityProfile profile = new LostCityProfile(safeName);
                List<String> warnings = profile.applyJsonAndValidate(el.getAsJsonObject());
                for (String w : warnings) {
                    logger.warning("Profile '" + safeName + "' (" + rawName + "): " + w);
                }
                loaded.put(safeName, profile);
            } catch (Exception ex) {
                logger.warning("Skipping corrupted profile file '" + rawName + "': " + ex.getMessage());
            }
        }
        if (!loaded.containsKey("default")) {
            loaded.put("default", new LostCityProfile("default"));
        }
        return Collections.unmodifiableMap(loaded);
    }

    /**
     * Atomically writes a profile to {@code profiles/<safeName>.json}.
     */
    public Path saveProfile(String rawName, LostCityProfile profile) throws IOException {
        String safeName = PathSecurity.validateSafeName(rawName, "profile");
        Files.createDirectories(profilesDir);
        Path target = PathSecurity.resolveInside(profilesDir, safeName + ".json");
        Path tmp = PathSecurity.resolveInside(profilesDir, safeName + ".json.tmp");
        JsonObject json = profile.toJson();
        json.addProperty("name", safeName);
        Files.writeString(tmp, GSON.toJson(json) + "\n", StandardCharsets.UTF_8);
        try {
            Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException atomicUnsupported) {
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
        }
        return target;
    }
}
