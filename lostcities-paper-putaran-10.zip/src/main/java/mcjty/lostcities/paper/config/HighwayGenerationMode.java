/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.config;

import java.util.Locale;

public enum HighwayGenerationMode {
    LEGACY,
    INTERCITY_NETWORK_V1;

    public static HighwayGenerationMode byName(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Highway generation mode cannot be blank");
        }
        return valueOf(name.trim().toUpperCase(Locale.ROOT));
    }
}
