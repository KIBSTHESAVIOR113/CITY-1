/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.config;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * 1:1 port of LostCities 26.3-12.0.2 {@code LostCityProfile}.
 * Every JSON key, default value, and numeric bound matches {@code LostCityProfile.java}
 * verbatim (see {@code docs/PROFILE_FIELD_PARITY.md}).
 */
public final class LostCityProfile {

    public static final int MIN_RAILWAY_SPACING = 4;
    public static final int MAX_RAILWAY_SPACING = 128;
    public static final int DEFAULT_RAILWAY_SPACING = 10;

    private final String name;
    private boolean isPublic = true;

    private String description = "Default generation, common cities, explosions";
    private String extraDescription = "";
    private String warning = "";
    private String worldStyle = "standard";
    private String iconFile = "";

    public int debrisToNearbyChunkFactor = 200;
    public String liquidBlock = "minecraft:water";
    public String baseBlock = "minecraft:stone";

    public float vineChance = 0.009f;
    public float randomLeafBlockChance = 0.1f;
    public int randomLeafBlockThickness = 2;
    public boolean avoidFoliage = false;

    public float scatteredChanceMultiplier = 1.0f;

    public boolean rubbleLayer = true;
    public float rubbleDirtScale = 3.0f;
    public float rubbleLeaveScale = 6.0f;

    public float ruinChance = 0.05f;
    public float ruinMinlevelPercent = 0.8f;
    public float ruinMaxlevelPercent = 1.0f;

    public int groundLevel = 71;
    public int seaLevel = -1;

    public boolean highwayRequiresTwoCities = true;
    public int highwayLevelFromCities = 3;
    public float highwayMainPerlinScale = 50.0f;
    public float highwaySecondaryPerlinScale = 10.0f;
    public float highwayPerlinFactor = 2.0f;
    public int highwayDistanceMask = 7;
    public boolean highwaySupports = true;
    public HighwayGenerationMode highwayGenerationMode = HighwayGenerationMode.INTERCITY_NETWORK_V1;
    public int highwayPlanningCellSize = 128;
    public int highwayHubSampleSpacing = 16;
    public float highwayHubMinimumPotential = 0.20f;
    public int highwayHubSearchRadiusCells = 2;
    public int highwayMinimumHubDistance = 64;
    public int highwayMaximumHubDistance = 320;
    public int highwayMaximumConnectionsPerHub = 2;
    public int highwayMinimumRouteLength = 40;
    public float highwayRouteCityPenalty = 1.0f;
    public int highwayNetworkLevel = 0;

    public float railwayDungeonChance = 0.01f;
    public boolean railwaysCanEnd = false;
    public boolean railwaysEnabled = true;
    public boolean railwayStationsEnabled = true;
    public boolean railwaySurfaceStationsEnabled = true;
    public int railwayLevelOffset = 0;
    public int railwaySpacingNorthSouth = DEFAULT_RAILWAY_SPACING;
    public int railwaySpacingEastWest = DEFAULT_RAILWAY_SPACING;

    public boolean explosionsInCitiesOnly = true;
    public boolean editMode = false;
    public boolean generateNether = false;
    public boolean generateSpawners = true;
    public boolean generateLoot = true;
    public boolean generateLighting = false;
    public boolean avoidWater = false;

    public float explosionChance = 0.002f;
    public int explosionMinRadius = 15;
    public int explosionMaxRadius = 35;
    public int explosionMinHeight = 75;
    public int explosionMaxHeight = 90;

    public float miniExplosionChance = 0.03f;
    public int miniExplosionMinRadius = 5;
    public int miniExplosionMaxRadius = 12;
    public int miniExplosionMinHeight = 60;
    public int miniExplosionMaxHeight = 100;

    public double cityChance = 0.01;
    public int cityMinRadius = 50;
    public int cityMaxRadius = 128;
    public double cityPerlinScale = 3.0;
    public double cityPerlinInnerScale = 0.1;
    public double cityPerlinOffset = 0.1;
    public float cityThreshold = 0.2f;

    public int citySpawnDistance1 = 0;
    public int citySpawnDistance2 = 0;
    public double citySpawnMultiplier1 = 1.0;
    public double citySpawnMultiplier2 = 1.0;

    public float cityStyleThreshold = -1.0f;
    public String cityStyleAlternative = "";
    public boolean cityAvoidVoid = true;

    public boolean grid32 = false;
    public float citySphereFactor = 1.2f;
    public float citySphereChance = 0.7f;
    public float sphereSurfaceVariation = 1.0f;
    public float outsideSurfaceVariation = 1.0f;
    public float monorailChance = 0.8f;
    public int citySphereClearAbove = 0;
    public int citySphereClearBelow = 0;
    public boolean citySphereClearAboveUntilAir = false;
    public boolean citySphereClearBelowUntilAir = false;
    public int outsideGroundLevel = -1;
    public String outsideProfile = "";
    public boolean onlyPredefined = false;
    public int monorailOffset = -2;

    public int cityLevel0Height = 75;
    public int cityLevel1Height = 83;
    public int cityLevel2Height = 91;
    public int cityLevel3Height = 99;
    public int cityLevel4Height = 107;
    public int cityLevel5Height = 115;
    public int cityLevel6Height = 123;
    public int cityLevel7Height = 131;
    public int cityMinHeight = 50;
    public int cityMaxHeight = 150;

    public int oceanCorrectionBorder = 4;
    public int terrainFixLowerMinOffset = -4;
    public int terrainFixLowerMaxOffset = -3;
    public int terrainFixUpperMinOffset = -1;
    public int terrainFixUpperMaxOffset = 1;

    public float chestWithoutLootChance = 0.2f;
    public float buildingWithoutLootChance = 0.2f;
    public float buildingChance = 0.3f;
    public int buildingMinFloors = 0;
    public int buildingMaxFloors = 8;
    public int buildingMinFloorsChance = 4;
    public int buildingMaxFloorsChance = 6;
    public int buildingMinCellars = 0;
    public int buildingMaxCellars = 3;
    public float buildingDoorwayChance = 0.6f;
    public float buildingFrontChance = 0.2f;

    public float parkChance = 0.2f;
    public float openLotParkChance = 0.8f;
    public float corridorChance = 0.7f;
    public float bridgeChance = 0.7f;
    public float plannedPrimaryBridgeChance = 1.0f;
    public int plannedPrimaryBridgeMaxLength = 12;
    public float fountainChance = 0.05f;

    public boolean bridgeSupports = true;
    public boolean parkElevation = true;
    public boolean parkBorder = true;
    public int parkStreetThreshold = 3;

    public StreetGenerationMode streetGenerationMode = StreetGenerationMode.HIERARCHICAL_GRID_V1;
    public int primaryRoadSpacingX = 8;
    public int primaryRoadSpacingZ = 8;
    public float primaryRoadOptionalChance = 0.45f;
    public int primaryRoadForceEvery = 4;
    public int secondaryRoadMinCountX = 0;
    public int secondaryRoadMaxCountX = 2;
    public int secondaryRoadMinCountZ = 0;
    public int secondaryRoadMaxCountZ = 2;
    public int minimumRoadSeparation = 4;
    public int minimumRoadEdgeDistance = 3;
    public float tertiaryRoadChance = 0.40f;
    public int tertiaryRoadMinLength = 2;
    public int tertiaryRoadMaxLength = 5;
    public MultiBuildingStreetConflict multiBuildingStreetConflict = MultiBuildingStreetConflict.OVERRIDE_MINOR;

    public boolean multiUseCorner = false;
    public boolean useAvgHeightmap = false;
    public int bedrockLayer = 1;

    public float horizon = -1.0f;
    public float fogRed = -1.0f;
    public float fogGreen = -1.0f;
    public float fogBlue = -1.0f;
    public float fogDensity = -1.0f;

    public String spawnBiome = "";
    public String spawnCity = "";
    public String spawnSphere = "";
    public boolean spawnNotInBuilding = false;
    public boolean forceSpawnInBuilding = false;
    public String[] forceSpawnBuildings = new String[0];
    public String[] forceSpawnParts = new String[0];
    public int spawnCheckRadius = 200;
    public int spawnRadiusIncrease = 100;
    public int spawnCheckAttempts = 20000;

    public LandscapeType landscapeType = LandscapeType.DEFAULT;
    public BiomeSelectionStrategy biomeSelectionStrategy = BiomeSelectionStrategy.ORIGINAL;

    public LostCityProfile(String name) {
        this.name = (name == null || name.isBlank()) ? "default" : name.trim().toLowerCase(Locale.ROOT);
    }

    public String getName() { return name; }
    public boolean isPublic() { return isPublic; }
    public void setPublic(boolean isPublic) { this.isPublic = isPublic; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description == null ? "" : description; }
    public String getExtraDescription() { return extraDescription; }
    public void setExtraDescription(String extraDescription) { this.extraDescription = extraDescription == null ? "" : extraDescription; }
    public String getWarning() { return warning; }
    public void setWarning(String warning) { this.warning = warning == null ? "" : warning; }
    public String getWorldStyle() { return worldStyle; }
    public void setWorldStyle(String worldStyle) { this.worldStyle = (worldStyle == null || worldStyle.isBlank()) ? "standard" : worldStyle; }
    public String getIconFile() { return iconFile; }
    public void setIconFile(String iconFile) { this.iconFile = iconFile == null ? "" : iconFile; }

    public boolean isDefault() { return landscapeType == LandscapeType.DEFAULT; }
    public boolean isFloating() { return landscapeType == LandscapeType.FLOATING; }
    public boolean isSpace() { return landscapeType == LandscapeType.SPACE; }
    public boolean isCavern() { return landscapeType == LandscapeType.CAVERN; }
    public boolean isSpheres() { return landscapeType == LandscapeType.SPHERES || landscapeType == LandscapeType.CAVERNSPHERES; }
    public boolean isVoidSpheres() { return landscapeType == LandscapeType.SPHERES; }
    public boolean isCavernSpheres() { return landscapeType == LandscapeType.CAVERNSPHERES; }

    public int getCityLevelHeight(int level) {
        return switch (level) {
            case 0 -> cityLevel0Height;
            case 1 -> cityLevel1Height;
            case 2 -> cityLevel2Height;
            case 3 -> cityLevel3Height;
            case 4 -> cityLevel4Height;
            case 5 -> cityLevel5Height;
            case 6 -> cityLevel6Height;
            default -> cityLevel7Height;
        };
    }

    /**
     * Populates fields from either flat JSON ({@code profiles/*.json}) or LostCities'
     * categorized JSON ({@code lostcity}, {@code cities}, {@code explosions}, {@code cityspheres}, {@code client}),
     * applying ONLY the exact numeric bounds defined in {@code LostCityProfile.java}.
     */
    public List<String> applyJsonAndValidate(JsonObject root) {
        List<String> warnings = new ArrayList<>();
        Map<String, JsonElement> flat = flattenJson(root);

        isPublic = readBool(flat, "public", isPublic, warnings);
        description = readStr(flat, "description", description);
        extraDescription = readStr(flat, "extraDescription", extraDescription);
        warning = readStr(flat, "warning", warning);
        worldStyle = readStr(flat, "worldStyle", worldStyle);
        iconFile = readStr(flat, "icon", iconFile);
        liquidBlock = readStr(flat, "liquidBlock", liquidBlock);
        baseBlock = readStr(flat, "baseBlock", baseBlock);

        spawnBiome = readStr(flat, "spawnBiome", spawnBiome);
        spawnCity = readStr(flat, "spawnCity", spawnCity);
        spawnSphere = readStr(flat, "spawnSphere", spawnSphere);
        spawnNotInBuilding = readBool(flat, "spawnNotInBuilding", spawnNotInBuilding, warnings);
        forceSpawnInBuilding = readBool(flat, "forceSpawnInBuilding", forceSpawnInBuilding, warnings);
        forceSpawnBuildings = readStrArray(flat, "forceSpawnBuildings", forceSpawnBuildings);
        forceSpawnParts = readStrArray(flat, "forceSpawnParts", forceSpawnParts);
        spawnCheckRadius = readInt(flat, "spawnCheckRadius", spawnCheckRadius, 1, 100000, warnings);
        spawnRadiusIncrease = readInt(flat, "spawnRadiusIncrease", spawnRadiusIncrease, 1, 100000, warnings);
        spawnCheckAttempts = readInt(flat, "spawnCheckAttempts", spawnCheckAttempts, 1, 1000000, warnings);

        scatteredChanceMultiplier = readFloat(flat, "scatteredChanceMultiplier", scatteredChanceMultiplier, 0.0f, 100.0f, warnings);
        terrainFixLowerMinOffset = readInt(flat, "terrainFixLowerMinOffset", terrainFixLowerMinOffset, -40, 40, warnings);
        terrainFixLowerMaxOffset = readInt(flat, "terrainFixLowerMaxOffset", terrainFixLowerMaxOffset, -40, 40, warnings);
        terrainFixUpperMinOffset = readInt(flat, "terrainFixUpperMinOffset", terrainFixUpperMinOffset, -40, 40, warnings);
        terrainFixUpperMaxOffset = readInt(flat, "terrainFixUpperMaxOffset", terrainFixUpperMaxOffset, -40, 40, warnings);

        vineChance = readFloat(flat, "vineChance", vineChance, 0.0f, 1.0f, warnings);
        randomLeafBlockChance = readFloat(flat, "randomLeafBlockChance", randomLeafBlockChance, 0.0f, 1.0f, warnings);
        randomLeafBlockThickness = readInt(flat, "randomLeafBlockThickness", randomLeafBlockThickness, 1, 8, warnings);
        avoidFoliage = readBool(flat, "avoidFoliage", avoidFoliage, warnings);

        String ltName = readStr(flat, "landscapeType", landscapeType.getName());
        LandscapeType parsedLt = LandscapeType.getTypeByName(ltName);
        if (parsedLt == null) {
            warnings.add("Unknown landscapeType '" + ltName + "'; using " + landscapeType.getName());
        } else {
            landscapeType = parsedLt;
        }

        String bsName = readStr(flat, "biomeSelectionStrategy", biomeSelectionStrategy.getName());
        BiomeSelectionStrategy parsedBs = BiomeSelectionStrategy.getTypeByName(bsName);
        if (parsedBs != null) {
            biomeSelectionStrategy = parsedBs;
        }

        rubbleLayer = readBool(flat, "rubbleLayer", rubbleLayer, warnings);
        rubbleDirtScale = readFloat(flat, "rubbleDirtScale", rubbleDirtScale, 0.0f, 100.0f, warnings);
        rubbleLeaveScale = readFloat(flat, "rubbleLeaveScale", rubbleLeaveScale, 0.0f, 100.0f, warnings);
        ruinChance = readFloat(flat, "ruinChance", ruinChance, 0.0f, 1.0f, warnings);
        ruinMinlevelPercent = readFloat(flat, "ruinMinlevelPercent", ruinMinlevelPercent, 0.0f, 1.0f, warnings);
        ruinMaxlevelPercent = readFloat(flat, "ruinMaxlevelPercent", ruinMaxlevelPercent, 0.0f, 1.0f, warnings);

        groundLevel = readInt(flat, "groundLevel", groundLevel, 2, 256, warnings);
        seaLevel = readInt(flat, "seaLevel", seaLevel, -1, 256, warnings);

        chestWithoutLootChance = readFloat(flat, "chestWithoutLootChance", chestWithoutLootChance, 0.0f, 1.0f, warnings);
        buildingWithoutLootChance = readFloat(flat, "buildingWithoutLootChance", buildingWithoutLootChance, 0.0f, 1.0f, warnings);
        buildingChance = readFloat(flat, "buildingChance", buildingChance, 0.0f, 1.0f, warnings);
        buildingMinFloors = readInt(flat, "buildingMinFloors", buildingMinFloors, 0, 60, warnings);
        buildingMaxFloors = readInt(flat, "buildingMaxFloors", buildingMaxFloors, 0, 60, warnings);
        buildingMinFloorsChance = readInt(flat, "buildingMinFloorsChance", buildingMinFloorsChance, 1, 60, warnings);
        buildingMaxFloorsChance = readInt(flat, "buildingMaxFloorsChance", buildingMaxFloorsChance, 1, 60, warnings);
        buildingMinCellars = readInt(flat, "buildingMinCellars", buildingMinCellars, 0, 20, warnings);
        buildingMaxCellars = readInt(flat, "buildingMaxCellars", buildingMaxCellars, 0, 20, warnings);
        buildingDoorwayChance = readFloat(flat, "buildingDoorwayChance", buildingDoorwayChance, 0.0f, 1.0f, warnings);
        buildingFrontChance = readFloat(flat, "buildingFrontChance", buildingFrontChance, 0.0f, 1.0f, warnings);

        parkChance = readFloat(flat, "parkChance", parkChance, 0.0f, 1.0f, warnings);
        openLotParkChance = readFloat(flat, "openLotParkChance", openLotParkChance, 0.0f, 1.0f, warnings);
        corridorChance = readFloat(flat, "corridorChance", corridorChance, 0.0f, 1.0f, warnings);
        bridgeChance = readFloat(flat, "bridgeChance", bridgeChance, 0.0f, 1.0f, warnings);
        plannedPrimaryBridgeChance = readFloat(flat, "plannedPrimaryBridgeChance", plannedPrimaryBridgeChance, 0.0f, 1.0f, warnings);
        plannedPrimaryBridgeMaxLength = readInt(flat, "plannedPrimaryBridgeMaxLength", plannedPrimaryBridgeMaxLength, 1, 64, warnings);
        bridgeSupports = readBool(flat, "bridgeSupports", bridgeSupports, warnings);
        parkElevation = readBool(flat, "parkElevation", parkElevation, warnings);
        parkBorder = readBool(flat, "parkBorder", parkBorder, warnings);
        parkStreetThreshold = readInt(flat, "parkStreetThreshold", parkStreetThreshold, 0, 8, warnings);

        String smName = readStr(flat, "streetGenerationMode", streetGenerationMode.name());
        try {
            streetGenerationMode = StreetGenerationMode.byName(smName);
        } catch (IllegalArgumentException ex) {
            warnings.add("Unknown streetGenerationMode '" + smName + "'; using " + streetGenerationMode.name());
        }
        primaryRoadSpacingX = readInt(flat, "primaryRoadSpacingX", primaryRoadSpacingX, 8, 128, warnings);
        primaryRoadSpacingZ = readInt(flat, "primaryRoadSpacingZ", primaryRoadSpacingZ, 8, 128, warnings);
        primaryRoadOptionalChance = readFloat(flat, "primaryRoadOptionalChance", primaryRoadOptionalChance, 0.0f, 1.0f, warnings);
        primaryRoadForceEvery = readInt(flat, "primaryRoadForceEvery", primaryRoadForceEvery, 1, 16, warnings);
        secondaryRoadMinCountX = readInt(flat, "secondaryRoadMinCountX", secondaryRoadMinCountX, 0, 128, warnings);
        secondaryRoadMaxCountX = readInt(flat, "secondaryRoadMaxCountX", secondaryRoadMaxCountX, 0, 128, warnings);
        secondaryRoadMinCountZ = readInt(flat, "secondaryRoadMinCountZ", secondaryRoadMinCountZ, 0, 128, warnings);
        secondaryRoadMaxCountZ = readInt(flat, "secondaryRoadMaxCountZ", secondaryRoadMaxCountZ, 0, 128, warnings);
        minimumRoadSeparation = readInt(flat, "minimumRoadSeparation", minimumRoadSeparation, 2, 32, warnings);
        minimumRoadEdgeDistance = readInt(flat, "minimumRoadEdgeDistance", minimumRoadEdgeDistance, 2, 32, warnings);
        tertiaryRoadChance = readFloat(flat, "tertiaryRoadChance", tertiaryRoadChance, 0.0f, 1.0f, warnings);
        tertiaryRoadMinLength = readInt(flat, "tertiaryRoadMinLength", tertiaryRoadMinLength, 1, 16, warnings);
        tertiaryRoadMaxLength = readInt(flat, "tertiaryRoadMaxLength", tertiaryRoadMaxLength, 1, 32, warnings);

        String mcName = readStr(flat, "multiBuildingStreetConflict", multiBuildingStreetConflict.name());
        try {
            multiBuildingStreetConflict = MultiBuildingStreetConflict.byName(mcName);
        } catch (IllegalArgumentException ex) {
            warnings.add("Unknown multiBuildingStreetConflict '" + mcName + "'; using " + multiBuildingStreetConflict.name());
        }

        fountainChance = readFloat(flat, "fountainChance", fountainChance, 0.0f, 1.0f, warnings);
        railwayDungeonChance = readFloat(flat, "railwayDungeonChance", railwayDungeonChance, 0.0f, 1.0f, warnings);
        railwaysCanEnd = readBool(flat, "railwaysCanEnd", railwaysCanEnd, warnings);
        railwaysEnabled = readBool(flat, "railwaysEnabled", railwaysEnabled, warnings);
        railwayStationsEnabled = readBool(flat, "railwayStationsEnabled", railwayStationsEnabled, warnings);
        railwaySurfaceStationsEnabled = readBool(flat, "railwaySurfaceStationsEnabled", railwaySurfaceStationsEnabled, warnings);
        railwayLevelOffset = readInt(flat, "railwayLevelOffset", railwayLevelOffset, -8, 2, warnings);
        railwaySpacingNorthSouth = readInt(flat, "railwaySpacingNorthSouth", railwaySpacingNorthSouth, MIN_RAILWAY_SPACING, MAX_RAILWAY_SPACING, warnings);
        railwaySpacingEastWest = readInt(flat, "railwaySpacingEastWest", railwaySpacingEastWest, MIN_RAILWAY_SPACING, MAX_RAILWAY_SPACING, warnings);

        multiUseCorner = readBool(flat, "multiUseCorner", multiUseCorner, warnings);
        useAvgHeightmap = readBool(flat, "useAvgHeightmap", useAvgHeightmap, warnings);

        highwayRequiresTwoCities = readBool(flat, "highwayRequiresTwoCities", highwayRequiresTwoCities, warnings);
        highwayLevelFromCities = readInt(flat, "highwayLevelFromCities", highwayLevelFromCities, 0, 4, warnings);
        highwayDistanceMask = readInt(flat, "highwayDistanceMask", highwayDistanceMask, 0, Integer.MAX_VALUE, warnings);
        highwayMainPerlinScale = readFloat(flat, "highwayMainPerlinScale", highwayMainPerlinScale, 1.0f, 1000.0f, warnings);
        highwaySecondaryPerlinScale = readFloat(flat, "highwaySecondaryPerlinScale", highwaySecondaryPerlinScale, 1.0f, 1000.0f, warnings);
        highwayPerlinFactor = readFloat(flat, "highwayPerlinFactor", highwayPerlinFactor, -100.0f, 100.0f, warnings);
        highwaySupports = readBool(flat, "highwaySupports", highwaySupports, warnings);
        String hmName = readStr(flat, "highwayGenerationMode", highwayGenerationMode.name());
        try {
            highwayGenerationMode = HighwayGenerationMode.byName(hmName);
        } catch (IllegalArgumentException ex) {
            warnings.add("Unknown highwayGenerationMode '" + hmName + "'; using " + highwayGenerationMode.name());
        }
        highwayPlanningCellSize = readInt(flat, "highwayPlanningCellSize", highwayPlanningCellSize, 32, 512, warnings);
        highwayHubSampleSpacing = readInt(flat, "highwayHubSampleSpacing", highwayHubSampleSpacing, 1, 512, warnings);
        highwayHubMinimumPotential = readFloat(flat, "highwayHubMinimumPotential", highwayHubMinimumPotential, 0.0f, 1.0f, warnings);
        highwayHubSearchRadiusCells = readInt(flat, "highwayHubSearchRadiusCells", highwayHubSearchRadiusCells, 0, 8, warnings);
        highwayMinimumHubDistance = readInt(flat, "highwayMinimumHubDistance", highwayMinimumHubDistance, 0, 4096, warnings);
        highwayMaximumHubDistance = readInt(flat, "highwayMaximumHubDistance", highwayMaximumHubDistance, 0, 4096, warnings);
        highwayMaximumConnectionsPerHub = readInt(flat, "highwayMaximumConnectionsPerHub", highwayMaximumConnectionsPerHub, 1, 8, warnings);
        highwayMinimumRouteLength = readInt(flat, "highwayMinimumRouteLength", highwayMinimumRouteLength, 0, 4096, warnings);
        highwayRouteCityPenalty = readFloat(flat, "highwayRouteCityPenalty", highwayRouteCityPenalty, 0.0f, 1000.0f, warnings);
        highwayNetworkLevel = readInt(flat, "highwayNetworkLevel", highwayNetworkLevel, 0, 32, warnings);

        bedrockLayer = readInt(flat, "bedrockLayer", bedrockLayer, 0, 10, warnings);
        editMode = readBool(flat, "editMode", editMode, warnings);
        generateNether = readBool(flat, "generateNether", generateNether, warnings);
        generateSpawners = readBool(flat, "generateSpawners", generateSpawners, warnings);
        generateLoot = readBool(flat, "generateLoot", generateLoot, warnings);
        generateLighting = readBool(flat, "generateLighting", generateLighting, warnings);
        avoidWater = readBool(flat, "avoidWater", avoidWater, warnings);

        cityChance = readDouble(flat, "cityChance", cityChance, -1.0, 1.0, warnings);
        citySpawnDistance1 = readInt(flat, "citySpawnDistance1", citySpawnDistance1, 0, 10000000, warnings);
        citySpawnDistance2 = readInt(flat, "citySpawnDistance2", citySpawnDistance2, 0, 10000000, warnings);
        citySpawnMultiplier1 = readDouble(flat, "citySpawnMultiplier1", citySpawnMultiplier1, 0.0, 1.0, warnings);
        citySpawnMultiplier2 = readDouble(flat, "citySpawnMultiplier2", citySpawnMultiplier2, 0.0, 1.0, warnings);
        cityMinRadius = readInt(flat, "cityMinRadius", cityMinRadius, 1, 2000, warnings);
        cityMaxRadius = readInt(flat, "cityMaxRadius", cityMaxRadius, 1, 2000, warnings);
        cityPerlinScale = readDouble(flat, "cityPerlinScale", cityPerlinScale, -1000000.0, 1000000.0, warnings);
        cityPerlinOffset = readDouble(flat, "cityPerlinOffset", cityPerlinOffset, -1000000.0, 1000000.0, warnings);
        cityPerlinInnerScale = readDouble(flat, "cityPerlinInnerScale", cityPerlinInnerScale, -1000000.0, 1000000.0, warnings);
        cityThreshold = readFloat(flat, "cityThreshold", cityThreshold, 0.0f, 1.0f, warnings);
        cityStyleThreshold = readFloat(flat, "cityStyleThreshold", cityStyleThreshold, -1.0f, 1.0f, warnings);
        cityStyleAlternative = readStr(flat, "cityStyleAlternative", cityStyleAlternative);
        cityAvoidVoid = readBool(flat, "cityAvoidVoid", cityAvoidVoid, warnings);

        cityLevel0Height = readInt(flat, "cityLevel0Height", cityLevel0Height, 1, 384, warnings);
        cityLevel1Height = readInt(flat, "cityLevel1Height", cityLevel1Height, 1, 384, warnings);
        cityLevel2Height = readInt(flat, "cityLevel2Height", cityLevel2Height, 1, 384, warnings);
        cityLevel3Height = readInt(flat, "cityLevel3Height", cityLevel3Height, 1, 384, warnings);
        cityLevel4Height = readInt(flat, "cityLevel4Height", cityLevel4Height, 1, 384, warnings);
        cityLevel5Height = readInt(flat, "cityLevel5Height", cityLevel5Height, 1, 384, warnings);
        cityLevel6Height = readInt(flat, "cityLevel6Height", cityLevel6Height, 1, 384, warnings);
        cityLevel7Height = readInt(flat, "cityLevel7Height", cityLevel7Height, 1, 384, warnings);
        cityMinHeight = readInt(flat, "cityMinHeight", cityMinHeight, -1024, 2048, warnings);
        cityMaxHeight = readInt(flat, "cityMaxHeight", cityMaxHeight, -1024, 2048, warnings);
        oceanCorrectionBorder = readInt(flat, "oceanCorrectionBorder", oceanCorrectionBorder, -255, 255, warnings);

        debrisToNearbyChunkFactor = readInt(flat, "debrisToNearbyChunkFactor", debrisToNearbyChunkFactor, 1, 10000, warnings);
        explosionChance = readFloat(flat, "explosionChance", explosionChance, 0.0f, 1.0f, warnings);
        explosionMinRadius = readInt(flat, "explosionMinRadius", explosionMinRadius, 1, 1000, warnings);
        explosionMaxRadius = readInt(flat, "explosionMaxRadius", explosionMaxRadius, 1, 3000, warnings);
        explosionMinHeight = readInt(flat, "explosionMinHeight", explosionMinHeight, 1, 256, warnings);
        explosionMaxHeight = readInt(flat, "explosionMaxHeight", explosionMaxHeight, 1, 256, warnings);
        miniExplosionChance = readFloat(flat, "miniExplosionChance", miniExplosionChance, 0.0f, 1.0f, warnings);
        miniExplosionMinRadius = readInt(flat, "miniExplosionMinRadius", miniExplosionMinRadius, 1, 1000, warnings);
        miniExplosionMaxRadius = readInt(flat, "miniExplosionMaxRadius", miniExplosionMaxRadius, 1, 3000, warnings);
        miniExplosionMinHeight = readInt(flat, "miniExplosionMinHeight", miniExplosionMinHeight, 1, 256, warnings);
        miniExplosionMaxHeight = readInt(flat, "miniExplosionMaxHeight", miniExplosionMaxHeight, 1, 256, warnings);
        explosionsInCitiesOnly = readBool(flat, "explosionsInCitiesOnly", explosionsInCitiesOnly, warnings);

        citySphereFactor = readFloat(flat, "citySphereFactor", citySphereFactor, 0.1f, 10.0f, warnings);
        citySphereChance = readFloat(flat, "citySphereChance", citySphereChance, 0.0f, 1.0f, warnings);
        citySphereClearAbove = readInt(flat, "citySphereClearAbove", citySphereClearAbove, 0, 1024, warnings);
        citySphereClearAboveUntilAir = readBool(flat, "citySphereClearAboveUntilAir", citySphereClearAboveUntilAir, warnings);
        citySphereClearBelow = readInt(flat, "citySphereClearBelow", citySphereClearBelow, 0, 1024, warnings);
        citySphereClearBelowUntilAir = readBool(flat, "citySphereClearBelowUntilAir", citySphereClearBelowUntilAir, warnings);
        sphereSurfaceVariation = readFloat(flat, "sphereSurfaceVariation", sphereSurfaceVariation, 0.0f, 1.0f, warnings);
        outsideSurfaceVariation = readFloat(flat, "outsideSurfaceVariation", outsideSurfaceVariation, 0.0f, 1.0f, warnings);
        monorailChance = readFloat(flat, "monorailChance", monorailChance, 0.0f, 1.0f, warnings);
        onlyPredefined = readBool(flat, "onlyPredefined", onlyPredefined, warnings);
        outsideGroundLevel = readInt(flat, "outsideGroundLevel", outsideGroundLevel, -1, 256, warnings);
        outsideProfile = readStr(flat, "outsideProfile", outsideProfile);
        monorailOffset = readInt(flat, "monorailOffset", monorailOffset, -100, 100, warnings);
        grid32 = readBool(flat, "grid32", grid32, warnings);

        horizon = readFloat(flat, "horizon", horizon, -1.0f, 256.0f, warnings);
        fogRed = readFloat(flat, "fogRed", fogRed, -1.0f, 1.0f, warnings);
        fogGreen = readFloat(flat, "fogGreen", fogGreen, -1.0f, 1.0f, warnings);
        fogBlue = readFloat(flat, "fogBlue", fogBlue, -1.0f, 1.0f, warnings);
        fogDensity = readFloat(flat, "fogDensity", fogDensity, -1.0f, 1.0f, warnings);

        return warnings;
    }

    public JsonObject toJson() {
        JsonObject obj = new JsonObject();
        obj.addProperty("name", name);
        obj.addProperty("public", isPublic);
        obj.addProperty("description", description);
        obj.addProperty("extraDescription", extraDescription);
        obj.addProperty("warning", warning);
        obj.addProperty("worldStyle", worldStyle);
        obj.addProperty("icon", iconFile);
        obj.addProperty("liquidBlock", liquidBlock);
        obj.addProperty("baseBlock", baseBlock);
        obj.addProperty("landscapeType", landscapeType.getName());
        obj.addProperty("biomeSelectionStrategy", biomeSelectionStrategy.getName());
        obj.addProperty("groundLevel", groundLevel);
        obj.addProperty("seaLevel", seaLevel);
        obj.addProperty("bedrockLayer", bedrockLayer);
        obj.addProperty("buildingChance", buildingChance);
        obj.addProperty("buildingMinFloors", buildingMinFloors);
        obj.addProperty("buildingMaxFloors", buildingMaxFloors);
        obj.addProperty("buildingMinFloorsChance", buildingMinFloorsChance);
        obj.addProperty("buildingMaxFloorsChance", buildingMaxFloorsChance);
        obj.addProperty("buildingMinCellars", buildingMinCellars);
        obj.addProperty("buildingMaxCellars", buildingMaxCellars);
        obj.addProperty("buildingDoorwayChance", buildingDoorwayChance);
        obj.addProperty("buildingFrontChance", buildingFrontChance);
        obj.addProperty("cityChance", cityChance);
        obj.addProperty("cityMinRadius", cityMinRadius);
        obj.addProperty("cityMaxRadius", cityMaxRadius);
        obj.addProperty("cityThreshold", cityThreshold);
        obj.addProperty("ruinChance", ruinChance);
        obj.addProperty("rubbleLayer", rubbleLayer);
        obj.addProperty("vineChance", vineChance);
        obj.addProperty("streetGenerationMode", streetGenerationMode.name());
        obj.addProperty("highwayGenerationMode", highwayGenerationMode.name());
        obj.addProperty("multiBuildingStreetConflict", multiBuildingStreetConflict.name());
        obj.addProperty("railwaysEnabled", railwaysEnabled);
        obj.addProperty("generateLoot", generateLoot);
        obj.addProperty("generateSpawners", generateSpawners);
        obj.addProperty("explosionChance", explosionChance);
        obj.addProperty("miniExplosionChance", miniExplosionChance);
        return obj;
    }

    private static Map<String, JsonElement> flattenJson(JsonObject root) {
        Map<String, JsonElement> map = new LinkedHashMap<>();
        if (root == null) {
            return map;
        }
        for (Map.Entry<String, JsonElement> entry : root.entrySet()) {
            if (entry.getValue() != null && entry.getValue().isJsonObject()) {
                for (Map.Entry<String, JsonElement> nested : entry.getValue().getAsJsonObject().entrySet()) {
                    map.put(nested.getKey(), nested.getValue());
                }
            } else {
                map.put(entry.getKey(), entry.getValue());
            }
        }
        return map;
    }

    private static String readStr(Map<String, JsonElement> flat, String key, String def) {
        JsonElement el = flat.get(key);
        if (el == null || !el.isJsonPrimitive()) {
            return def;
        }
        return el.getAsString();
    }

    private static String[] readStrArray(Map<String, JsonElement> flat, String key, String[] def) {
        JsonElement el = flat.get(key);
        if (el == null || !el.isJsonArray()) {
            return Arrays.copyOf(def, def.length);
        }
        JsonArray arr = el.getAsJsonArray();
        String[] res = new String[arr.size()];
        for (int i = 0; i < arr.size(); i++) {
            res[i] = arr.get(i).getAsString();
        }
        return res;
    }

    private static boolean readBool(Map<String, JsonElement> flat, String key, boolean def, List<String> warnings) {
        JsonElement el = flat.get(key);
        if (el == null || el.isJsonNull()) {
            return def;
        }
        if (!el.isJsonPrimitive()) {
            warnings.add(key + " is not a boolean; using default " + def);
            return def;
        }
        return el.getAsBoolean();
    }

    private static int readInt(Map<String, JsonElement> flat, String key, int def, int min, int max, List<String> warnings) {
        JsonElement el = flat.get(key);
        if (el == null || el.isJsonNull()) {
            return def;
        }
        try {
            int val = el.getAsInt();
            if (val < min || val > max) {
                warnings.add(key + "=" + val + " out of source range [" + min + "," + max + "]; using default " + def);
                return def;
            }
            return val;
        } catch (RuntimeException ex) {
            warnings.add(key + " invalid int; using default " + def);
            return def;
        }
    }

    private static float readFloat(Map<String, JsonElement> flat, String key, float def, float min, float max, List<String> warnings) {
        JsonElement el = flat.get(key);
        if (el == null || el.isJsonNull()) {
            return def;
        }
        try {
            float val = el.getAsFloat();
            if (Float.isNaN(val) || Float.isInfinite(val) || val < min || val > max) {
                warnings.add(key + "=" + val + " out of source range [" + min + "," + max + "]; using default " + def);
                return def;
            }
            return val;
        } catch (RuntimeException ex) {
            warnings.add(key + " invalid float; using default " + def);
            return def;
        }
    }

    private static double readDouble(Map<String, JsonElement> flat, String key, double def, double min, double max, List<String> warnings) {
        JsonElement el = flat.get(key);
        if (el == null || el.isJsonNull()) {
            return def;
        }
        try {
            double val = el.getAsDouble();
            if (Double.isNaN(val) || Double.isInfinite(val) || val < min || val > max) {
                warnings.add(key + "=" + val + " out of source range [" + min + "," + max + "]; using default " + def);
                return def;
            }
            return val;
        } catch (RuntimeException ex) {
            warnings.add(key + " invalid double; using default " + def);
            return def;
        }
    }
}
