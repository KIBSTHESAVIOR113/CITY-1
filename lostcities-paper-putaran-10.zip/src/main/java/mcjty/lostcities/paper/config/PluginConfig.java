/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.config;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Immutable snapshot of global plugin settings loaded from {@code config.yml}.
 */
public record PluginConfig(
        String defaultProfile,
        boolean debug,
        int todoQueueSizePerTick,
        long maxJsonFileBytes,
        boolean bedTeleportEnabled,
        String specialBedBlock,
        String defaultLostCityWorld,
        int chunkPlanMaxEntries,
        int heightmapMaxEntries,
        int cityMaxEntries,
        int highwayHubMaxEntries,
        int highwayDependencyMaxEntries,
        int cacheTtlSeconds,
        int highwayWorkerThreads,
        boolean suppressVanillaDecorationsInCities,
        boolean avoidStructuresAdjacent,
        boolean avoidVillages,
        boolean avoidVillagesAdjacent,
        boolean avoidFlattening,
        Set<String> avoidStructures,
        Map<String, String> worldProfiles
) {
    public static PluginConfig fromYaml(FileConfiguration cfg) {
        String defaultProfile = cfg.getString("general.default-profile", "default").trim().toLowerCase(Locale.ROOT);
        boolean debug = cfg.getBoolean("general.debug", false);
        int todoPerTick = Math.max(1, cfg.getInt("general.todo-queue-size-per-tick", 50));
        long maxJson = Math.max(65536L, cfg.getLong("general.max-json-file-bytes", 2097152L));
        boolean bedTeleport = cfg.getBoolean("general.bed-teleport-enabled", true);
        String specialBed = cfg.getString("general.special-bed-block", "minecraft:diamond_block");
        String defaultWorld = cfg.getString("general.default-lostcity-world", "lostcity");

        int chunkPlanMax = Math.max(256, cfg.getInt("caches.chunk-plan-max-entries", 4096));
        int heightmapMax = Math.max(256, cfg.getInt("caches.heightmap-max-entries", 4096));
        int cityMax = Math.max(128, cfg.getInt("caches.city-max-entries", 2048));
        int highwayHubMax = Math.max(256, cfg.getInt("caches.highway-hub-max-entries", 4096));
        int highwayDepMax = Math.max(128, cfg.getInt("caches.highway-dependency-max-entries", 2048));
        int cacheTtl = Math.max(30, cfg.getInt("caches.cache-ttl-seconds", 300));
        int hwThreads = Math.max(1, Math.min(8, cfg.getInt("caches.highway-worker-threads", 2)));

        boolean suppressDecor = cfg.getBoolean("generation.suppress-vanilla-decorations-in-cities", true);
        boolean avoidStructAdj = cfg.getBoolean("generation.avoid-structures-adjacent", false);
        boolean avoidVillages = cfg.getBoolean("generation.avoid-villages", true);
        boolean avoidVillagesAdj = cfg.getBoolean("generation.avoid-villages-adjacent", false);
        boolean avoidFlattening = cfg.getBoolean("generation.avoid-flattening", false);

        List<String> rawAvoid = cfg.getStringList("generation.avoid-structures");
        Set<String> avoidSet = new LinkedHashSet<>();
        for (String s : rawAvoid) {
            if (s != null && !s.isBlank()) {
                avoidSet.add(s.trim().toLowerCase(Locale.ROOT));
            }
        }

        Map<String, String> worldMap = new LinkedHashMap<>();
        ConfigurationSection worldsSec = cfg.getConfigurationSection("worlds");
        if (worldsSec != null) {
            for (String worldName : worldsSec.getKeys(false)) {
                String prof = worldsSec.getString(worldName, defaultProfile);
                if (prof != null && !prof.isBlank()) {
                    worldMap.put(worldName, prof.trim().toLowerCase(Locale.ROOT));
                }
            }
        }

        return new PluginConfig(
                defaultProfile,
                debug,
                todoPerTick,
                maxJson,
                bedTeleport,
                specialBed,
                defaultWorld,
                chunkPlanMax,
                heightmapMax,
                cityMax,
                highwayHubMax,
                highwayDepMax,
                cacheTtl,
                hwThreads,
                suppressDecor,
                avoidStructAdj,
                avoidVillages,
                avoidVillagesAdj,
                avoidFlattening,
                Collections.unmodifiableSet(avoidSet),
                Collections.unmodifiableMap(worldMap)
        );
    }

    public static PluginConfig defaults() {
        return new PluginConfig(
                "default", false, 50, 2097152L, true, "minecraft:diamond_block", "lostcity",
                4096, 4096, 2048, 4096, 2048, 300, 2,
                true, false, true, false, false,
                Set.of("minecraft:mansion", "minecraft:jungle_pyramid", "minecraft:desert_pyramid",
                        "minecraft:igloo", "minecraft:swamp_huts", "minecraft:pillager_outpost"),
                Map.of("lostcity", "default")
        );
    }
}
