/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.util;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.LongAdder;

/**
 * Lock-free rolling window metrics for chunk generation latency (avg ms, p95 ms, total chunks).
 */
public final class Metrics {

    private static final int WINDOW = 1024;
    private final long[] samplesNanos = new long[WINDOW];
    private final AtomicInteger cursor = new AtomicInteger(0);
    private final LongAdder chunksGenerated = new LongAdder();
    private final LongAdder totalNanos = new LongAdder();

    public void recordChunkNanos(long nanos) {
        int idx = Math.floorMod(cursor.getAndIncrement(), WINDOW);
        samplesNanos[idx] = nanos;
        chunksGenerated.increment();
        totalNanos.add(nanos);
    }

    public long chunksGenerated() {
        return chunksGenerated.sum();
    }

    public double averageMs() {
        long count = chunksGenerated.sum();
        return count == 0 ? 0.0 : (totalNanos.sum() / (double) count) / 1_000_000.0;
    }

    public double p95Ms() {
        int n = (int) Math.min(WINDOW, chunksGenerated.sum());
        if (n <= 0) return 0.0;
        long[] copy = new long[n];
        System.arraycopy(samplesNanos, 0, copy, 0, n);
        Arrays.sort(copy);
        int idx = Math.min(n - 1, (int) Math.ceil(n * 0.95) - 1);
        return copy[Math.max(0, idx)] / 1_000_000.0;
    }
}
