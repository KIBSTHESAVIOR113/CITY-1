/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.util;

import java.util.Random;

/**
 * Deterministic RNG helpers matching LostCities 26.3-12.0.2 seed mixing,
 * MurmurHash3 finalizer, QualityRandom, and per-chunk palette LCG (Invariants #1-#5).
 */
public final class DeterministicRandom {

    public static final long DIM_MIX_PRIME = 0x9e3779b97f4a7c15L;
    public static final long TRANSITION_SALT = 0x6a09e667f3bcc909L;
    public static final long CHUNK_X_PRIME = 257017164707L;
    public static final long CHUNK_Z_PRIME = 101754694003L;

    private DeterministicRandom() {
    }

    /**
     * Exact port of {@code GenerationContext.mixSeed} (Invariant #3).
     */
    public static long mixChunkSeed(long worldSeed, String dimensionId, int chunkX, int chunkZ) {
        long mixed = worldSeed;
        mixed ^= (long) dimensionId.hashCode() * DIM_MIX_PRIME;
        mixed ^= (long) chunkX * CHUNK_X_PRIME;
        mixed ^= (long) chunkZ * CHUNK_Z_PRIME;
        mixed ^= mixed >>> 33;
        mixed *= 0xff51afd7ed558ccdL;
        mixed ^= mixed >>> 33;
        mixed *= 0xc4ceb9fe1a85ec53L;
        mixed ^= mixed >>> 33;
        return mixed;
    }

    /**
     * Exact port of {@code LostCityTerrainFeature} transition noise seed (Invariant #2).
     */
    public static long transitionSeed(long worldSeed, String dimensionId) {
        return worldSeed ^ (long) dimensionId.hashCode() * DIM_MIX_PRIME ^ TRANSITION_SALT;
    }

    /**
     * Exact port of pre-explosion/debris reseed (Invariant #5).
     */
    public static long damageReseed(int chunkX, int chunkZ) {
        return chunkX * CHUNK_X_PRIME + chunkZ * CHUNK_Z_PRIME;
    }

    /**
     * Exact port of {@code BuildingInfo.getBuildingRandom} using {@code QualityRandom}.
     */
    public static Random buildingRandom(int chunkX, int chunkZ, long worldSeed) {
        long seed = worldSeed + chunkX * 341873128712L + chunkZ * 132897987541L;
        return new QualityRandom(seed);
    }

    /**
     * Exact port of McJty's {@code QualityRandom} (xorshift64* override of {@link Random}).
     */
    public static final class QualityRandom extends Random {
        private long state;

        public QualityRandom(long seed) {
            super(seed);
            this.state = seed == 0L ? 0x9e3779b97f4a7c15L : seed;
        }

        @Override
        public synchronized void setSeed(long seed) {
            super.setSeed(seed);
            this.state = seed == 0L ? 0x9e3779b97f4a7c15L : seed;
        }

        @Override
        protected int next(int bits) {
            long x = state;
            x ^= (x << 21);
            x ^= (x >>> 35);
            x ^= (x << 4);
            state = x;
            return (int) (x >>> (64 - bits));
        }
    }

    /**
     * Lightweight deterministic 2D Perlin/value noise generator seeded from a shared {@link Random}
     * in exact construction order (Invariant #1).
     */
    public static final class PerlinNoise2D {
        private final int[] perm = new int[512];
        private final int octaves;
        private final double xOffset;
        private final double zOffset;

        public PerlinNoise2D(Random rand, int octaves) {
            this.octaves = Math.max(1, octaves);
            this.xOffset = rand.nextDouble() * 256.0;
            this.zOffset = rand.nextDouble() * 256.0;
            int[] p = new int[256];
            for (int i = 0; i < 256; i++) {
                p[i] = i;
            }
            for (int i = 0; i < 256; i++) {
                int j = rand.nextInt(256 - i) + i;
                int tmp = p[i];
                p[i] = p[j];
                p[j] = tmp;
                perm[i] = p[i];
                perm[i + 256] = p[i];
            }
        }

        public double sample(double x, double z) {
            double total = 0.0;
            double freq = 1.0;
            double amp = 1.0;
            double maxAmp = 0.0;
            for (int i = 0; i < octaves; i++) {
                total += singleNoise((x + xOffset) * freq, (z + zOffset) * freq) * amp;
                maxAmp += amp;
                freq *= 2.0;
                amp *= 0.5;
            }
            return maxAmp == 0.0 ? 0.0 : total / maxAmp;
        }

        private double singleNoise(double x, double z) {
            int xi = (int) Math.floor(x) & 255;
            int zi = (int) Math.floor(z) & 255;
            double xf = x - Math.floor(x);
            double zf = z - Math.floor(z);
            double u = fade(xf);
            double v = fade(zf);
            int aa = perm[perm[xi] + zi];
            int ab = perm[perm[xi] + zi + 1];
            int ba = perm[perm[xi + 1] + zi];
            int bb = perm[perm[xi + 1] + zi + 1];
            double x1 = lerp(u, grad(aa, xf, zf), grad(ba, xf - 1.0, zf));
            double x2 = lerp(u, grad(ab, xf, zf - 1.0), grad(bb, xf - 1.0, zf - 1.0));
            return lerp(v, x1, x2);
        }

        private static double fade(double t) { return t * t * t * (t * (t * 6.0 - 15.0) + 10.0); }
        private static double lerp(double t, double a, double b) { return a + t * (b - a); }
        private static double grad(int hash, double x, double z) {
            return switch (hash & 3) {
                case 0 -> x + z;
                case 1 -> -x + z;
                case 2 -> x - z;
                default -> -x - z;
            };
        }
    }
}
