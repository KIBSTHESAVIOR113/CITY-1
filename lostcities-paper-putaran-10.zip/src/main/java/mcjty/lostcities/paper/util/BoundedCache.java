/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.util;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.LongAdder;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Function;

/**
 * Thread-safe bounded LRU + TTL cache with hit/miss counters replacing all
 * static unbounded caches from the Fabric source.
 */
public final class BoundedCache<K, V> {

    private record Entry<V>(V value, long expiresAtNanos) {}

    private final int maxEntries;
    private final long ttlNanos;
    private final ReentrantLock lock = new ReentrantLock();
    private final LinkedHashMap<K, Entry<V>> map;
    private final LongAdder hits = new LongAdder();
    private final LongAdder misses = new LongAdder();

    public BoundedCache(int maxEntries, int ttlSeconds) {
        this.maxEntries = Math.max(16, maxEntries);
        this.ttlNanos = Math.max(1L, ttlSeconds) * 1_000_000_000L;
        this.map = new LinkedHashMap<>(Math.min(this.maxEntries, 256), 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<K, Entry<V>> eldest) {
                return size() > BoundedCache.this.maxEntries;
            }
        };
    }

    public V get(K key) {
        long now = System.nanoTime();
        lock.lock();
        try {
            Entry<V> e = map.get(key);
            if (e == null) {
                misses.increment();
                return null;
            }
            if (e.expiresAtNanos() < now) {
                map.remove(key);
                misses.increment();
                return null;
            }
            hits.increment();
            return e.value();
        } finally {
            lock.unlock();
        }
    }

    public void put(K key, V value) {
        long expires = System.nanoTime() + ttlNanos;
        lock.lock();
        try {
            map.put(key, new Entry<>(value, expires));
        } finally {
            lock.unlock();
        }
    }

    public V computeIfAbsent(K key, Function<K, V> factory) {
        V existing = get(key);
        if (existing != null) {
            return existing;
        }
        V computed = factory.apply(key);
        if (computed != null) {
            put(key, computed);
        }
        return computed;
    }

    public void clear() {
        lock.lock();
        try {
            map.clear();
        } finally {
            lock.unlock();
        }
    }

    public int size() {
        lock.lock();
        try {
            return map.size();
        } finally {
            lock.unlock();
        }
    }

    public long hits() { return hits.sum(); }
    public long misses() { return misses.sum(); }

    public double hitRate() {
        long h = hits.sum();
        long total = h + misses.sum();
        return total == 0 ? 0.0 : (double) h / total;
    }
}
