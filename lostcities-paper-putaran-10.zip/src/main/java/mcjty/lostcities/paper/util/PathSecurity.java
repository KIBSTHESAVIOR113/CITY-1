/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.util;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Security helpers preventing path traversal and unbounded JSON memory allocation.
 */
public final class PathSecurity {

    public static final long DEFAULT_MAX_JSON_BYTES = 2L * 1024L * 1024L;
    private static final Pattern SAFE_IDENTIFIER = Pattern.compile("^[a-z0-9][a-z0-9_.-]{0,63}$");

    private PathSecurity() {
    }

    public static String validateSafeName(String rawName, String kind) {
        if (rawName == null || rawName.isBlank()) {
            throw new IllegalArgumentException(kind + " name cannot be blank");
        }
        String normalized = rawName.trim().toLowerCase(Locale.ROOT);
        if (normalized.contains("..") || normalized.contains("/") || normalized.contains("\\")
                || !SAFE_IDENTIFIER.matcher(normalized).matches()) {
            throw new IllegalArgumentException("Unsafe " + kind + " name '" + rawName + "': only [a-z0-9_.-] allowed");
        }
        return normalized;
    }

    public static Path resolveInside(Path baseDir, String relativePath) {
        if (relativePath == null || relativePath.isBlank()) {
            throw new IllegalArgumentException("Relative path cannot be blank");
        }
        Path base = baseDir.toAbsolutePath().normalize();
        Path resolved = base.resolve(relativePath).normalize();
        if (!resolved.startsWith(base)) {
            throw new IllegalArgumentException("Path traversal detected: '" + relativePath + "' escapes " + base);
        }
        return resolved;
    }

    public static String readBoundedUtf8(Path file, long maxBytes) throws IOException {
        long size = Files.size(file);
        if (size > maxBytes) {
            throw new IOException("File " + file.getFileName() + " exceeds maximum allowed JSON size ("
                    + size + " > " + maxBytes + " bytes)");
        }
        return Files.readString(file, StandardCharsets.UTF_8);
    }

    public static String normalizeResourceId(String raw, String defaultNamespace) {
        if (raw == null || raw.isBlank()) {
            return "";
        }
        String trimmed = raw.trim().toLowerCase(Locale.ROOT);
        int colon = trimmed.indexOf(':');
        if (colon < 0) {
            return defaultNamespace.toLowerCase(Locale.ROOT) + ":" + trimmed;
        }
        return trimmed;
    }
}
