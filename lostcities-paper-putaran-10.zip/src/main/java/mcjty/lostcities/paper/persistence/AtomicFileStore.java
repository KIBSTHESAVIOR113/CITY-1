/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.persistence;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import mcjty.lostcities.paper.util.PathSecurity;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.Optional;
import java.util.logging.Logger;

/**
 * Crash-safe atomic JSON file store (write temp in same directory -> fsync -> ATOMIC_MOVE)
 * with explicit schema versioning and corruption fallback (Invariant #17, DEC-05).
 */
public final class AtomicFileStore {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path baseDir;
    private final long maxBytes;
    private final Logger logger;

    public AtomicFileStore(Path baseDir, long maxBytes, Logger logger) {
        this.baseDir = baseDir.toAbsolutePath().normalize();
        this.maxBytes = maxBytes;
        this.logger = logger;
    }

    public void writeVersioned(String relativeName, int formatVersion, JsonObject payload) throws IOException {
        Files.createDirectories(baseDir);
        Path target = PathSecurity.resolveInside(baseDir, relativeName);
        Files.createDirectories(target.getParent());
        Path tmp = PathSecurity.resolveInside(target.getParent(), target.getFileName().toString() + ".tmp");

        JsonObject envelope = new JsonObject();
        envelope.addProperty("formatVersion", formatVersion);
        envelope.add("data", payload);
        byte[] bytes = (GSON.toJson(envelope) + "\n").getBytes(StandardCharsets.UTF_8);

        try (FileChannel ch = FileChannel.open(tmp,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) {
            ByteBuffer buf = ByteBuffer.wrap(bytes);
            while (buf.hasRemaining()) {
                ch.write(buf);
            }
            ch.force(true);
        }

        try {
            Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException ex) {
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    public Optional<JsonObject> readVersioned(String relativeName, int expectedFormatVersion) {
        Path target = PathSecurity.resolveInside(baseDir, relativeName);
        if (!Files.isRegularFile(target)) {
            return Optional.empty();
        }
        try {
            String raw = PathSecurity.readBoundedUtf8(target, maxBytes);
            JsonElement parsed = JsonParser.parseString(raw);
            if (!parsed.isJsonObject()) {
                logger.warning("Corrupted persistence file '" + relativeName + "': root is not JSON object; regenerating from seed.");
                return Optional.empty();
            }
            JsonObject envelope = parsed.getAsJsonObject();
            int version = envelope.has("formatVersion") ? envelope.get("formatVersion").getAsInt() : -1;
            if (version != expectedFormatVersion) {
                logger.warning("Persistence version mismatch in '" + relativeName + "' (got " + version
                        + ", expected " + expectedFormatVersion + "); regenerating from seed.");
                return Optional.empty();
            }
            if (!envelope.has("data") || !envelope.get("data").isJsonObject()) {
                logger.warning("Corrupted persistence file '" + relativeName + "': missing data payload.");
                return Optional.empty();
            }
            return Optional.of(envelope.getAsJsonObject("data"));
        } catch (Exception ex) {
            logger.warning("Failed reading persistence file '" + relativeName + "' (" + ex.getMessage()
                    + "); falling back to deterministic seed regeneration.");
            return Optional.empty();
        }
    }
}
