/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.spawn;

import io.papermc.paper.event.player.AsyncPlayerSpawnLocationEvent;
import mcjty.lostcities.paper.LostCitiesPlugin;
import mcjty.lostcities.paper.core.BuildingInfo;
import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.generator.WorldDimensionState;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

/**
 * Replaces {@code PlayerSpawnFinderMixin} and {@code CavernSpawn} using Paper 26.3's
 * {@link AsyncPlayerSpawnLocationEvent} (DEC-04) plus main-thread safety verification on join.
 */
public final class SpawnHandler implements Listener {

    private static final int CAVERN_MAX_FLOOR_Y = 124;
    private final LostCitiesPlugin plugin;

    public SpawnHandler(LostCitiesPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onAsyncSpawn(AsyncPlayerSpawnLocationEvent event) {
        if (!event.isNewPlayer()) {
            return;
        }
        Location current = event.getSpawnLocation();
        if (current == null || current.getWorld() == null) {
            return;
        }
        World world = current.getWorld();
        WorldDimensionState state = plugin.getDimensionState(world.getUID());
        if (state == null) {
            return;
        }
        // Pure deterministic planner lookup safe for async thread
        int[] cityChunk = findNearestCityChunk(state, 0, 0, Math.min(32, Math.max(8, state.profile().spawnCheckRadius >> 4)));
        if (cityChunk != null) {
            int x = (cityChunk[0] << 4) + 8;
            int z = (cityChunk[1] << 4) + 8;
            int y = Math.min(world.getMaxHeight() - 3, Math.max(world.getMinHeight() + 2, state.profile().groundLevel + 2));
            event.setSpawnLocation(new Location(world, x + 0.5, y, z + 0.5));
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Location loc = event.getPlayer().getLocation();
        World world = loc.getWorld();
        if (world == null) return;
        WorldDimensionState state = plugin.getDimensionState(world.getUID());
        if (state == null) return;

        // Ensure player does not suffocate inside a solid block (especially cavern profiles)
        if (!isSafeFeetLocation(world, loc.getBlockX(), loc.getBlockY(), loc.getBlockZ(), state.profile().isCavern())) {
            Location safe = findSafeColumnLocation(world, loc.getBlockX(), loc.getBlockZ(),
                    state.profile().groundLevel, state.profile().isCavern());
            event.getPlayer().teleport(safe);
        }
    }

    public int[] findNearestCityChunk(WorldDimensionState state, int originCx, int originCz, int maxRadiusChunks) {
        for (int r = 0; r <= maxRadiusChunks; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (Math.abs(dx) != r && Math.abs(dz) != r) continue;
                    ChunkCoord coord = new ChunkCoord("lostcities:" + state.worldName(), originCx + dx, originCz + dz);
                    if (BuildingInfo.computeCityFactor(coord, state.seed(), state.profile()) >= state.profile().cityThreshold) {
                        return new int[]{originCx + dx, originCz + dz};
                    }
                }
            }
        }
        return null;
    }

    public static boolean isSafeFeetLocation(World world, int x, int y, int z, boolean cavern) {
        int maxFloor = cavern ? Math.min(CAVERN_MAX_FLOOR_Y, world.getMaxHeight() - 3) : world.getMaxHeight() - 3;
        if (y - 1 < world.getMinHeight() || y - 1 > maxFloor) return false;
        Block floor = world.getBlockAt(x, y - 1, z);
        Block feet = world.getBlockAt(x, y, z);
        Block head = world.getBlockAt(x, y + 1, z);
        return floor.getType().isSolid() && floor.getType() != Material.BEDROCK && floor.getType() != Material.MAGMA_BLOCK
                && feet.isPassable() && head.isPassable();
    }

    public static Location findSafeColumnLocation(World world, int x, int z, int preferredY, boolean cavern) {
        int maxY = cavern ? Math.min(CAVERN_MAX_FLOOR_Y, world.getMaxHeight() - 3) : world.getMaxHeight() - 3;
        int minY = world.getMinHeight() + 1;
        int start = Math.max(minY, Math.min(maxY, preferredY));
        for (int y = start; y <= maxY; y++) {
            if (isSafeFeetLocation(world, x, y, z, cavern)) {
                return new Location(world, x + 0.5, y, z + 0.5);
            }
        }
        int highest = Math.max(minY, Math.min(maxY, world.getHighestBlockYAt(x, z) + 1));
        return new Location(world, x + 0.5, highest, z + 0.5);
    }
}
