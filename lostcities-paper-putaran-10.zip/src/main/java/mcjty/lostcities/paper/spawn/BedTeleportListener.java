/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.spawn;

import mcjty.lostcities.paper.LostCitiesPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerBedEnterEvent;

import java.util.Locale;

/**
 * Paper equivalent of {@code ForgeEventHandlers.onPlayerSleepInBed}: sleeping on a bed
 * placed over {@code special-bed-block} surrounded by skulls teleports the player to
 * the configured LostCities world.
 */
public final class BedTeleportListener implements Listener {

    private final LostCitiesPlugin plugin;

    public BedTeleportListener(LostCitiesPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onBedEnter(PlayerBedEnterEvent event) {
        if (!plugin.getPluginConfig().bedTeleportEnabled()) return;
        Block bed = event.getBed();
        Material special = Material.matchMaterial(plugin.getPluginConfig().specialBedBlock().replace("minecraft:", "").toUpperCase(Locale.ROOT));
        if (special == null || bed.getRelative(BlockFace.DOWN).getType() != special) {
            return;
        }
        int skulls = 0;
        for (BlockFace face : new BlockFace[]{BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST}) {
            String name = bed.getRelative(face).getType().name();
            if (name.endsWith("_SKULL") || name.endsWith("_HEAD")) {
                skulls++;
            }
        }
        if (skulls < 2) return;

        World target = Bukkit.getWorld(plugin.getPluginConfig().defaultLostCityWorld());
        if (target == null || target.equals(event.getPlayer().getWorld())) return;
        event.setCancelled(true);
        Location dest = SpawnHandler.findSafeColumnLocation(target, 0, 0, 72, false);
        event.getPlayer().teleport(dest);
    }
}
