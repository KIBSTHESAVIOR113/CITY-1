/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.compat;

import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.Biome;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.loot.LootTable;
import org.bukkit.permissions.PermissionDefault;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Isolates version-sensitive Paper 26.3 API calls behind a single adapter contract.
 */
public interface PaperApiAdapter {

    @NotNull WorldCreator createWorldCreator(@NotNull String worldName,
                                             @Nullable NamespacedKey worldKey,
                                             long seed,
                                             @NotNull ChunkGenerator generator,
                                             @Nullable BiomeProvider biomeProvider);

    @NotNull Biome resolveBiome(@NotNull String namespacedId);

    @NotNull String getBiomeKey(@NotNull Biome biome);

    @NotNull List<Biome> getAvailableBiomes();

    @Nullable LootTable lookupLootTable(@NotNull NamespacedKey key);

    void registerPermission(@NotNull String node, @NotNull String description, @NotNull PermissionDefault defaultValue);

    default boolean hasLostCityDimensionHeight(@NotNull World world) {
        return world.getMinHeight() == 0 && world.getMaxHeight() == 256;
    }

    @NotNull String getAdapterName();
}
