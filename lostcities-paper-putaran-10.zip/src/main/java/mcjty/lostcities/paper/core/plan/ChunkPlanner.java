/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.plan;

import mcjty.lostcities.paper.core.BuildingInfo;
import mcjty.lostcities.paper.core.ChunkCoord;
import mcjty.lostcities.paper.util.BoundedCache;

import java.util.function.Supplier;

/**
 * Instance-scoped (per-world) staged planner replacing the static global {@code ChunkPlanner}.
 */
public final class ChunkPlanner {

    private final BoundedCache<ChunkCoord, ChunkPlan> plans;
    private final BoundedCache<ChunkCoord, Integer> cityLevels;

    public ChunkPlanner(int maxEntries, int ttlSeconds) {
        this.plans = new BoundedCache<>(maxEntries, ttlSeconds);
        this.cityLevels = new BoundedCache<>(maxEntries, ttlSeconds);
    }

    public int cityLevel(ChunkCoord coord, Supplier<Integer> supplier) {
        return cityLevels.computeIfAbsent(coord, k -> supplier.get());
    }

    public <T> T highway(ChunkCoord coord, Supplier<T> supplier) {
        ChunkPlan plan = plans.computeIfAbsent(coord, k -> new ChunkPlan());
        return plan.highway(supplier);
    }

    public BuildingInfo.Characteristics characteristics(ChunkCoord coord, Supplier<Staged<BuildingInfo.Characteristics>> supplier) {
        ChunkPlan plan = plans.computeIfAbsent(coord, k -> new ChunkPlan());
        return plan.characteristics(supplier);
    }

    public BuildingInfo buildingInfo(ChunkCoord coord, Supplier<Staged<BuildingInfo>> supplier) {
        ChunkPlan plan = plans.computeIfAbsent(coord, k -> new ChunkPlan());
        return plan.buildingInfo(supplier);
    }

    public void clear() {
        plans.clear();
        cityLevels.clear();
    }

    public int planCacheSize() { return plans.size(); }
    public double planHitRate() { return plans.hitRate(); }
}
