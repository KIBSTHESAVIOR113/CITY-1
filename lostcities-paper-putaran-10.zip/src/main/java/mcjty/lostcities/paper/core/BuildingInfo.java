/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

import mcjty.lostcities.paper.assets.AssetModels;
import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.plan.ChunkPlanner;
import mcjty.lostcities.paper.core.plan.Staged;
import mcjty.lostcities.paper.util.DeterministicRandom;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Deterministic per-chunk city, building, floor, cellar, and street metadata.
 * Preserves {@code FLOORHEIGHT = 6} (Invariant #6) and {@code west->east->north->south}
 * {@code prefersLonely} evaluation order (Invariant #8).
 */
public final class BuildingInfo {

    public static final int FLOOR_HEIGHT = 6;

    public record Characteristics(
            boolean isCity,
            boolean couldHaveBuilding,
            int cityLevel,
            String buildingId,
            String multiBuildingId,
            int multiRelX,
            int multiRelZ,
            int multiDimX,
            int multiDimZ,
            String cityStyleId
    ) {
        public boolean isSingle() {
            return multiDimX <= 1 && multiDimZ <= 1;
        }
    }

    public final ChunkCoord coord;
    public final LostCityProfile profile;
    public final boolean isCity;
    public final boolean hasBuilding;
    public final int cityLevel;
    public final int groundLevel;
    public final int waterLevel;
    public final int floors;
    public final int cellars;
    public final String buildingId;
    public final String cityStyleId;
    public final Transform partTransform;
    public final List<String> floorParts;
    public final List<String> cellarParts;
    public final String roofPart;
    public final float ruinHeight;
    public final boolean hasLoot;

    private BuildingInfo(
            ChunkCoord coord,
            LostCityProfile profile,
            boolean isCity,
            boolean hasBuilding,
            int cityLevel,
            int groundLevel,
            int waterLevel,
            int floors,
            int cellars,
            String buildingId,
            String cityStyleId,
            Transform partTransform,
            List<String> floorParts,
            List<String> cellarParts,
            String roofPart,
            float ruinHeight,
            boolean hasLoot
    ) {
        this.coord = coord;
        this.profile = profile;
        this.isCity = isCity;
        this.hasBuilding = hasBuilding;
        this.cityLevel = cityLevel;
        this.groundLevel = groundLevel;
        this.waterLevel = waterLevel;
        this.floors = floors;
        this.cellars = cellars;
        this.buildingId = buildingId;
        this.cityStyleId = cityStyleId;
        this.partTransform = partTransform;
        this.floorParts = List.copyOf(floorParts);
        this.cellarParts = List.copyOf(cellarParts);
        this.roofPart = roofPart;
        this.ruinHeight = ruinHeight;
        this.hasLoot = hasLoot;
    }

    public int getCityGroundLevel() {
        return groundLevel + cityLevel * FLOOR_HEIGHT;
    }

    public int getMaxHeight() {
        return getCityGroundLevel() + (floors + 1) * FLOOR_HEIGHT;
    }

    public static float computeCityFactor(ChunkCoord coord, long worldSeed, LostCityProfile profile) {
        // Deterministic radial city centers on a 16-chunk macro-grid matching LostCities cityChance logic
        int cx = coord.chunkX();
        int cz = coord.chunkZ();
        int cellRadius = Math.max(1, (profile.cityMaxRadius >> 4) + 1);
        int cellX = Math.floorDiv(cx, 16);
        int cellZ = Math.floorDiv(cz, 16);
        float maxFactor = 0.0f;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                int gx = cellX + dx;
                int gz = cellZ + dz;
                Random r = DeterministicRandom.buildingRandom(gx * 31, gz * 31, worldSeed ^ 0x517cc1b727220a95L);
                if (r.nextDouble() < Math.max(0.05, profile.cityChance * 12.0)) {
                    int centerX = gx * 16 + r.nextInt(16);
                    int centerZ = gz * 16 + r.nextInt(16);
                    int radiusBlocks = profile.cityMinRadius + r.nextInt(Math.max(1, profile.cityMaxRadius - profile.cityMinRadius + 1));
                    double radiusChunks = Math.max(2.0, radiusBlocks / 16.0);
                    double dist = Math.hypot(cx - centerX, cz - centerZ);
                    if (dist < radiusChunks) {
                        float f = (float) (1.0 - (dist / radiusChunks));
                        if (f > maxFactor) {
                            maxFactor = f;
                        }
                    }
                }
            }
        }
        return maxFactor;
    }

    public static Staged<Characteristics> computeCharacteristics(
            ChunkCoord coord, long worldSeed, LostCityProfile profile, AssetRegistry registry) {
        float cityFactor = computeCityFactor(coord, worldSeed, profile);
        boolean isCity = cityFactor >= profile.cityThreshold;
        int cityLevel = Math.max(0, Math.min(7, (int) (cityFactor * 3.0f)));
        Random rand = DeterministicRandom.buildingRandom(coord.chunkX(), coord.chunkZ(), worldSeed);

        List<String> buildingIds = new ArrayList<>(registry.buildings().keySet());
        String chosenBuilding = buildingIds.isEmpty() ? "" : buildingIds.get(rand.nextInt(buildingIds.size()));
        List<String> styleIds = new ArrayList<>(registry.cityStyles().keySet());
        String chosenStyle = styleIds.isEmpty() ? "lostcities:citystyle_standard" : styleIds.get(rand.nextInt(styleIds.size()));

        boolean couldHaveBuilding = isCity && (rand.nextFloat() < profile.buildingChance);
        return new Staged<>(new Characteristics(
                isCity, couldHaveBuilding, cityLevel, chosenBuilding, "", 0, 0, 1, 1, chosenStyle
        ), true);
    }

    public static BuildingInfo get(
            ChunkCoord coord, long worldSeed, LostCityProfile profile, AssetRegistry registry, ChunkPlanner planner) {
        return planner.buildingInfo(coord, () -> compute(coord, worldSeed, profile, registry, planner));
    }

    private static Staged<BuildingInfo> compute(
            ChunkCoord coord, long worldSeed, LostCityProfile profile, AssetRegistry registry, ChunkPlanner planner) {
        Characteristics ch = planner.characteristics(coord, () -> computeCharacteristics(coord, worldSeed, profile, registry));
        Random rand = DeterministicRandom.buildingRandom(coord.chunkX(), coord.chunkZ(), worldSeed);

        boolean hasBuilding = ch.couldHaveBuilding();
        // Invariant #8: evaluate prefersLonely strictly in order west -> east -> north -> south
        if (hasBuilding && ch.isSingle()) {
            ChunkCoord[] neighbors = new ChunkCoord[]{coord.west(), coord.east(), coord.north(), coord.south()};
            for (ChunkCoord n : neighbors) {
                Characteristics nCh = planner.characteristics(n, () -> computeCharacteristics(n, worldSeed, profile, registry));
                AssetModels.BuildingAsset nb = registry.getBuilding(nCh.buildingId());
                float lonely = nb == null ? 0.0f : nb.prefersLonely();
                if (rand.nextFloat() < lonely) {
                    hasBuilding = false;
                    break;
                }
            }
        }

        int minF = profile.buildingMinFloors;
        int maxF = Math.max(minF, profile.buildingMaxFloors);
        int floors = minF + rand.nextInt(Math.max(1, maxF - minF + 1));
        int minC = profile.buildingMinCellars;
        int maxC = Math.max(minC, profile.buildingMaxCellars);
        int cellars = minC + rand.nextInt(Math.max(1, maxC - minC + 1));

        Transform transform = Transform.fromIndex(rand.nextInt(4));
        List<String> allParts = new ArrayList<>(registry.parts().keySet());
        List<String> floorParts = new ArrayList<>();
        List<String> cellarParts = new ArrayList<>();
        String roofPart = "";
        if (hasBuilding && !allParts.isEmpty()) {
            for (int i = 0; i < floors; i++) {
                floorParts.add(allParts.get(rand.nextInt(allParts.size())));
            }
            for (int i = 0; i < cellars; i++) {
                cellarParts.add(allParts.get(rand.nextInt(allParts.size())));
            }
            roofPart = allParts.get(rand.nextInt(allParts.size()));
        }

        float ruinHeight = -1.0f;
        if (profile.ruinChance > 0.0f && rand.nextFloat() < profile.ruinChance) {
            ruinHeight = profile.ruinMinlevelPercent
                    + rand.nextFloat() * Math.max(0.0f, profile.ruinMaxlevelPercent - profile.ruinMinlevelPercent);
        }
        boolean hasLoot = profile.generateLoot && rand.nextFloat() >= profile.buildingWithoutLootChance;
        int wl = profile.seaLevel == -1 ? 63 : profile.seaLevel;

        return new Staged<>(new BuildingInfo(
                coord, profile, ch.isCity(), hasBuilding, ch.cityLevel(),
                profile.groundLevel, wl, floors, cellars,
                ch.buildingId(), ch.cityStyleId(), transform,
                floorParts, cellarParts, roofPart, ruinHeight, hasLoot
        ), true);
    }
}
