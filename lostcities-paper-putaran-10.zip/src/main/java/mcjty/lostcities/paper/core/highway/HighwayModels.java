/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.highway;

import java.util.List;

/**
 * Immutable data records for inter-city highway hubs, segments, routes, and per-chunk occupancy.
 */
public final class HighwayModels {

    private HighwayModels() {
    }

    public enum HighwayAxis { X, Z }

    public record HubKey(int planningCellX, int planningCellZ) implements Comparable<HubKey> {
        @Override
        public int compareTo(HubKey o) {
            int cmp = Integer.compare(this.planningCellX, o.planningCellX);
            return cmp != 0 ? cmp : Integer.compare(this.planningCellZ, o.planningCellZ);
        }
    }

    public record HighwayHub(HubKey key, int chunkX, int chunkZ, int potentialScore, int cityLevel) {}

    public record HighwaySegment(int startX, int startZ, int endX, int endZ, HighwayAxis axis) {
        public boolean contains(int cx, int cz) {
            if (axis == HighwayAxis.X) {
                return cz == startZ && cx >= Math.min(startX, endX) && cx <= Math.max(startX, endX);
            }
            return cx == startX && cz >= Math.min(startZ, endZ) && cz <= Math.max(startZ, endZ);
        }
    }

    public record HighwayRoute(HighwayHub firstHub, HighwayHub secondHub, List<HighwaySegment> segments, int level) {}

    public record HighwayInfo(int xLevel, int zLevel) {
        public static final HighwayInfo NONE = new HighwayInfo(-1, -1);
        public boolean hasHighway() { return xLevel >= 0 || zLevel >= 0; }
    }
}
