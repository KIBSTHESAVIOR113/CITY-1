/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.plan;

import mcjty.lostcities.paper.core.BuildingInfo;

import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Supplier;

/**
 * Per-chunk staged memoization holding separate locks per stage (Invariant #7).
 */
public final class ChunkPlan {

    private final ReentrantLock infrastructureLock = new ReentrantLock();
    private final ReentrantLock characteristicsLock = new ReentrantLock();
    private final ReentrantLock chunkLock = new ReentrantLock();

    private volatile Object highway;
    private volatile BuildingInfo.Characteristics characteristics;
    private volatile BuildingInfo buildingInfo;

    @SuppressWarnings("unchecked")
    public <T> T highway(Supplier<T> supplier) {
        Object res = highway;
        if (res != null) return (T) res;
        infrastructureLock.lock();
        try {
            if (highway == null) {
                highway = supplier.get();
            }
            return (T) highway;
        } finally {
            infrastructureLock.unlock();
        }
    }

    public BuildingInfo.Characteristics characteristics(Supplier<Staged<BuildingInfo.Characteristics>> supplier) {
        BuildingInfo.Characteristics res = characteristics;
        if (res != null) return res;
        characteristicsLock.lock();
        try {
            if (characteristics != null) return characteristics;
            Staged<BuildingInfo.Characteristics> staged = supplier.get();
            if (staged.cacheable()) {
                characteristics = staged.value();
            }
            return staged.value();
        } finally {
            characteristicsLock.unlock();
        }
    }

    public BuildingInfo buildingInfo(Supplier<Staged<BuildingInfo>> supplier) {
        BuildingInfo res = buildingInfo;
        if (res != null) return res;
        chunkLock.lock();
        try {
            if (buildingInfo != null) return buildingInfo;
            Staged<BuildingInfo> staged = supplier.get();
            if (staged.cacheable()) {
                buildingInfo = staged.value();
            }
            return staged.value();
        } finally {
            chunkLock.unlock();
        }
    }
}
