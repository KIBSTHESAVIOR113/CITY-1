/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

import mcjty.lostcities.paper.assets.AssetModels;
import mcjty.lostcities.paper.assets.AssetRegistry;
import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.plan.ChunkPlanner;
import mcjty.lostcities.paper.util.DeterministicRandom;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Core deterministic chunk generator executing the exact stage ordering documented in
 * {@code ARCHITECTURE.md} (Invariants #1-#11).
 */
public final class LostCityTerrainFeature {

    public static final int FLOOR_HEIGHT = BuildingInfo.FLOOR_HEIGHT;

    private final long worldSeed;
    private final String dimensionId;
    private final LostCityProfile profile;
    private final DeterministicRandom.PerlinNoise2D rubbleNoise;
    private final DeterministicRandom.PerlinNoise2D leavesNoise;
    private final DeterministicRandom.PerlinNoise2D ruinNoise;
    private final DeterministicRandom.PerlinNoise2D bottomLayerNoise;
    private final DeterministicRandom.PerlinNoise2D terrainTransitionNoise;

    public LostCityTerrainFeature(long worldSeed, String dimensionId, LostCityProfile profile) {
        this.worldSeed = worldSeed;
        this.dimensionId = dimensionId;
        this.profile = profile;
        // Invariant #1: exact construction order of all 4 Perlin noises from one Random(worldSeed)
        Random shared = new Random(worldSeed);
        this.rubbleNoise = new DeterministicRandom.PerlinNoise2D(shared, 4);
        this.leavesNoise = new DeterministicRandom.PerlinNoise2D(shared, 4);
        this.ruinNoise = new DeterministicRandom.PerlinNoise2D(shared, 4);
        this.bottomLayerNoise = new DeterministicRandom.PerlinNoise2D(shared, 4);
        // Invariant #2: exact transition seed formula
        this.terrainTransitionNoise = new DeterministicRandom.PerlinNoise2D(
                new Random(DeterministicRandom.transitionSeed(worldSeed, dimensionId)), 2);
    }

    /**
     * Generates LostCities structures into {@code surface} for {@code (chunkX, chunkZ)} and
     * returns any out-of-bounds block placements to be enqueued in {@link GlobalTodo}.
     */
    public Map<Long, String> generateChunk(
            BlockSurface surface,
            int chunkX,
            int chunkZ,
            AssetRegistry registry,
            ChunkPlanner planner,
            LootSpawnerSink lootSpawnerSink
    ) {
        try (GenerationContext.Scope ignored = GenerationContext.open(worldSeed, dimensionId, chunkX, chunkZ)) {
            ChunkDriver driver = GenerationContext.current().driver();
            driver.begin(surface, chunkX, chunkZ);

            ChunkCoord coord = new ChunkCoord(dimensionId, chunkX, chunkZ);
            ChunkHeightmap heightmap = sampleHeightmap(surface, chunkX, chunkZ);
            BuildingInfo info = BuildingInfo.get(coord, worldSeed, profile, registry, planner);
            CompiledPalette palette = buildPaletteFor(registry, info);

            if (info.isCity) {
                doCityChunk(driver, info, heightmap, registry, palette, lootSpawnerSink);
            } else {
                doNormalChunk(driver, info, heightmap);
            }

            // Invariant #5: deterministic reseed immediately before explosions & debris
            GenerationContext.current().reseedForDamage(chunkX, chunkZ);
            applyDamageAndDebris(driver, info, chunkX, chunkZ);

            return driver.flush();
        }
    }

    private void doCityChunk(
            ChunkDriver driver,
            BuildingInfo info,
            ChunkHeightmap heightmap,
            AssetRegistry registry,
            CompiledPalette palette,
            LootSpawnerSink lootSpawnerSink
    ) {
        int minY = driver.minY();
        int ground = Math.max(minY + profile.bedrockLayer, Math.min(driver.maxY() - 16, info.getCityGroundLevel()));

        // Stage 1: Bedrock layer & high water level
        if (profile.isDefault() || profile.isVoidSpheres()) {
            for (int x = 0; x < 16; x++) {
                for (int z = 0; z < 16; z++) {
                    driver.setBlockRange(x, minY, z, minY + profile.bedrockLayer, "minecraft:bedrock");
                }
            }
        }

        // Stage 2: City surface leveling
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                driver.setBlockRange(x, minY + profile.bedrockLayer, z, ground, profile.baseBlock);
                driver.setBlockRange(x, ground + 1, z, Math.min(driver.maxY(), ground + 24), "minecraft:air");
            }
        }

        // Stage 3: Building OR Street
        if (info.hasBuilding) {
            generateBuilding(driver, info, ground, registry, palette, lootSpawnerSink);
        } else {
            generateStreet(driver, info, ground, palette);
        }

        // Stage 4: Ruins
        if (info.ruinHeight >= 0.0f && info.hasBuilding) {
            applyRuins(driver, info, ground);
        }

        // Stage 5: Rubble layer
        if (profile.rubbleLayer && (!info.hasBuilding || info.ruinHeight >= 0.0f)) {
            generateRubble(driver, info, ground);
        }
    }

    private void doNormalChunk(ChunkDriver driver, BuildingInfo info, ChunkHeightmap heightmap) {
        // Preserve vanilla terrain; only apply subtle terrain transition noise near cities if needed
        double n = terrainTransitionNoise.sample(info.coord.chunkX() * 0.25, info.coord.chunkZ() * 0.25);
        if (n > 0.9999 && profile.rubbleLayer) {
            int y = heightmap.getHeight(8, 8);
            if (y >= driver.minY() && y < driver.maxY()) {
                driver.setBlockLocal(8, y, 8, "minecraft:mossy_cobblestone");
            }
        }
    }

    private void generateBuilding(
            ChunkDriver driver,
            BuildingInfo info,
            int ground,
            AssetRegistry registry,
            CompiledPalette palette,
            LootSpawnerSink lootSpawnerSink
    ) {
        // Cellars below ground
        for (int c = 1; c <= info.cellars; c++) {
            int baseY = ground - c * FLOOR_HEIGHT;
            if (baseY < driver.minY() + profile.bedrockLayer) break;
            String partId = info.cellarParts.get(c - 1);
            placePart(driver, info, registry.getPart(partId), baseY, palette, lootSpawnerSink);
        }
        // Above-ground floors
        for (int f = 0; f < info.floors; f++) {
            int baseY = ground + f * FLOOR_HEIGHT;
            if (baseY + FLOOR_HEIGHT >= driver.maxY()) break;
            String partId = info.floorParts.get(f);
            placePart(driver, info, registry.getPart(partId), baseY, palette, lootSpawnerSink);
        }
        // Roof
        int roofY = ground + info.floors * FLOOR_HEIGHT;
        if (roofY < driver.maxY() && !info.roofPart.isEmpty()) {
            placePart(driver, info, registry.getPart(info.roofPart), roofY, palette, lootSpawnerSink);
        }
    }

    private void placePart(
            ChunkDriver driver,
            BuildingInfo info,
            AssetModels.PartAsset part,
            int baseY,
            CompiledPalette palette,
            LootSpawnerSink sink
    ) {
        if (part == null) {
            return;
        }
        List<List<String>> slices = part.slices();
        int maxSlices = Math.min(slices.size(), FLOOR_HEIGHT);
        for (int dy = 0; dy < maxSlices; dy++) {
            int y = baseY + dy;
            if (y < driver.minY() || y >= driver.maxY()) continue;
            List<String> rows = slices.get(dy);
            for (int lz = 0; lz < Math.min(16, rows.size()); lz++) {
                String row = rows.get(lz);
                for (int lx = 0; lx < Math.min(16, row.length()); lx++) {
                    char ch = row.charAt(lx);
                    int tx = info.partTransform.mapX(lx, lz);
                    int tz = info.partTransform.mapZ(lx, lz);
                    CompiledPalette.Entry entry = palette.getEntry(ch);
                    if (entry == null) continue;
                    String blockId = entry.sample();
                    driver.setBlockLocal(tx, y, tz, blockId);
                    if (sink != null) {
                        int wx = (info.coord.chunkX() << 4) + tx;
                        int wz = (info.coord.chunkZ() << 4) + tz;
                        if (info.hasLoot && entry.lootCondition() != null && !entry.lootCondition().isEmpty()) {
                            sink.onLootBlock(wx, y, wz, entry.lootCondition(), info);
                        }
                        if (profile.generateSpawners && entry.mobCondition() != null && !entry.mobCondition().isEmpty()) {
                            sink.onSpawnerBlock(wx, y, wz, entry.mobCondition(), info);
                        }
                    }
                }
            }
        }
    }

    private void generateStreet(ChunkDriver driver, BuildingInfo info, int ground, CompiledPalette palette) {
        String streetBlock = palette.getBlock('s');
        if (streetBlock == null) streetBlock = "minecraft:gray_concrete";
        String sidewalkBlock = "minecraft:stone_brick_slab";
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                boolean border = (x <= 1 || x >= 14 || z <= 1 || z >= 14);
                driver.setBlockLocal(x, ground, z, border ? sidewalkBlock : streetBlock);
            }
        }
    }

    private void applyRuins(ChunkDriver driver, BuildingInfo info, int ground) {
        int totalHeight = Math.max(1, info.floors * FLOOR_HEIGHT);
        int baseCutY = ground + (int) (totalHeight * info.ruinHeight);
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                double n = ruinNoise.sample((info.coord.chunkX() * 16 + x) * 0.15, (info.coord.chunkZ() * 16 + z) * 0.15);
                int cutY = baseCutY + (int) (n * 4.0);
                driver.setBlockRange(x, cutY, z, Math.min(driver.maxY(), ground + totalHeight + FLOOR_HEIGHT), "minecraft:air");
            }
        }
    }

    private void generateRubble(ChunkDriver driver, BuildingInfo info, int ground) {
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                double d = rubbleNoise.sample((info.coord.chunkX() * 16 + x) / Math.max(0.1, profile.rubbleDirtScale),
                        (info.coord.chunkZ() * 16 + z) / Math.max(0.1, profile.rubbleDirtScale));
                if (d > 0.65) {
                    driver.setBlockLocal(x, ground + 1, z, "minecraft:mossy_cobblestone");
                } else {
                    double l = leavesNoise.sample((info.coord.chunkX() * 16 + x) / Math.max(0.1, profile.rubbleLeaveScale),
                            (info.coord.chunkZ() * 16 + z) / Math.max(0.1, profile.rubbleLeaveScale));
                    if (l > 0.72 && !profile.avoidFoliage) {
                        driver.setBlockLocal(x, ground + 1, z, "minecraft:oak_leaves[persistent=true]");
                    }
                }
            }
        }
    }

    private void applyDamageAndDebris(ChunkDriver driver, BuildingInfo info, int chunkX, int chunkZ) {
        Random rand = GenerationContext.current().random();
        if (profile.miniExplosionChance > 0.0f && rand.nextFloat() < profile.miniExplosionChance) {
            if (!profile.explosionsInCitiesOnly || info.isCity) {
                int cx = rand.nextInt(16);
                int cz = rand.nextInt(16);
                int cy = Math.max(driver.minY() + 2, Math.min(driver.maxY() - 2,
                        profile.miniExplosionMinHeight + rand.nextInt(Math.max(1, profile.miniExplosionMaxHeight - profile.miniExplosionMinHeight + 1))));
                int radius = profile.miniExplosionMinRadius + rand.nextInt(Math.max(1, profile.miniExplosionMaxRadius - profile.miniExplosionMinRadius + 1));
                int r2 = radius * radius;
                for (int dx = -radius; dx <= radius; dx++) {
                    int x = cx + dx;
                    if (x < 0 || x >= 16) continue;
                    for (int dz = -radius; dz <= radius; dz++) {
                        int z = cz + dz;
                        if (z < 0 || z >= 16) continue;
                        for (int dy = -radius; dy <= radius; dy++) {
                            int y = cy + dy;
                            if (y <= driver.minY() + profile.bedrockLayer || y >= driver.maxY()) continue;
                            if (dx * dx + dy * dy + dz * dz <= r2) {
                                driver.setBlockLocal(x, y, z, "minecraft:air");
                            }
                        }
                    }
                }
            }
        }
    }

    private ChunkHeightmap sampleHeightmap(BlockSurface surface, int chunkX, int chunkZ) {
        ChunkHeightmap hm = new ChunkHeightmap();
        int bx = chunkX << 4;
        int bz = chunkZ << 4;
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                hm.set(x, z, surface.sampleSurfaceHeight(bx + x, bz + z, profile.groundLevel));
            }
        }
        hm.finish();
        return hm;
    }

    private CompiledPalette buildPaletteFor(AssetRegistry registry, BuildingInfo info) {
        List<String> names = new ArrayList<>();
        if (registry.getPalette("common") != null) {
            names.add("common");
        }
        if (registry.getPalette("default") != null) {
            names.add("default");
        }
        if (names.isEmpty() && !registry.palettes().isEmpty()) {
            names.add(registry.palettes().keySet().iterator().next());
        }
        return new CompiledPalette(registry, names);
    }

    public double sampleBottomLayerNoise(int worldX, int worldZ) {
        return bottomLayerNoise.sample(worldX * 0.1, worldZ * 0.1);
    }

    @FunctionalInterface
    public interface LootSpawnerSink {
        void onLootBlock(int worldX, int y, int worldZ, String conditionName, BuildingInfo info);
        default void onSpawnerBlock(int worldX, int y, int worldZ, String conditionName, BuildingInfo info) {}
    }
}
