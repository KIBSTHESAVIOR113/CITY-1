/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core.gen;

import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.core.BuildingInfo;
import mcjty.lostcities.paper.core.ChunkDriver;
import mcjty.lostcities.paper.core.GenerationContext;
import mcjty.lostcities.paper.core.highway.HighwayModels.HighwayInfo;

import java.util.Random;

/**
 * Deterministic generators for Highways, Bridges, Railways, Monorails, Corridors,
 * Supports, Doors, Scattered structures, Stuff decorations, and CitySpheres.
 */
public final class StructureGenerators {

    private StructureGenerators() {
    }

    public static void generateHighways(ChunkDriver driver, BuildingInfo info, HighwayInfo highway) {
        if (!highway.hasHighway()) return;
        int deckY = Math.min(driver.maxY() - 6, info.getCityGroundLevel() + Math.max(0, Math.max(highway.xLevel(), highway.zLevel())) * BuildingInfo.FLOOR_HEIGHT + 6);
        if (highway.xLevel() >= 0) {
            for (int x = 0; x < 16; x++) {
                for (int z = 3; z <= 12; z++) {
                    boolean rail = (z == 3 || z == 12);
                    driver.setBlockLocal(x, deckY, z, rail ? "minecraft:stone_brick_wall" : "minecraft:black_concrete");
                    driver.setBlockRange(x, deckY + 1, z, deckY + 5, "minecraft:air");
                }
            }
            if (info.profile.highwaySupports) {
                generateSupportPillar(driver, 4, deckY - 1, 4);
                generateSupportPillar(driver, 11, deckY - 1, 11);
            }
        }
        if (highway.zLevel() >= 0) {
            for (int z = 0; z < 16; z++) {
                for (int x = 3; x <= 12; x++) {
                    boolean rail = (x == 3 || x == 12);
                    driver.setBlockLocal(x, deckY, z, rail ? "minecraft:stone_brick_wall" : "minecraft:black_concrete");
                    driver.setBlockRange(x, deckY + 1, z, deckY + 5, "minecraft:air");
                }
            }
        }
    }

    public static void generateRailways(ChunkDriver driver, BuildingInfo info) {
        LostCityProfile profile = info.profile;
        if (!profile.railwaysEnabled) return;
        int ns = Math.max(LostCityProfile.MIN_RAILWAY_SPACING, profile.railwaySpacingNorthSouth);
        int ew = Math.max(LostCityProfile.MIN_RAILWAY_SPACING, profile.railwaySpacingEastWest);
        boolean railX = Math.floorMod(info.coord.chunkZ(), ew) == 0;
        boolean railZ = Math.floorMod(info.coord.chunkX(), ns) == 0;
        if (!railX && !railZ) return;

        int railY = Math.max(driver.minY() + 4, info.getCityGroundLevel() - BuildingInfo.FLOOR_HEIGHT + profile.railwayLevelOffset * BuildingInfo.FLOOR_HEIGHT);
        if (railX) {
            for (int x = 0; x < 16; x++) {
                for (int z = 6; z <= 9; z++) {
                    driver.setBlockLocal(x, railY - 1, z, "minecraft:cobblestone");
                    driver.setBlockRange(x, railY, z, railY + 4, "minecraft:air");
                    if (z == 7 || z == 8) {
                        driver.setBlockLocal(x, railY, z, "minecraft:rail");
                    }
                }
            }
        }
        if (railZ) {
            for (int z = 0; z < 16; z++) {
                for (int x = 6; x <= 9; x++) {
                    driver.setBlockLocal(x, railY - 1, z, "minecraft:cobblestone");
                    driver.setBlockRange(x, railY, z, railY + 4, "minecraft:air");
                    if (x == 7 || x == 8) {
                        driver.setBlockLocal(x, railY, z, "minecraft:rail");
                    }
                }
            }
        }
    }

    public static void generateCorridors(ChunkDriver driver, BuildingInfo info) {
        Random rand = GenerationContext.current().random();
        if (!info.isCity || rand.nextFloat() >= info.profile.corridorChance) return;
        int y = Math.max(driver.minY() + 3, info.getCityGroundLevel() - BuildingInfo.FLOOR_HEIGHT);
        for (int x = 6; x <= 9; x++) {
            for (int z = 0; z < 16; z++) {
                driver.setBlockLocal(x, y, z, "minecraft:stone_bricks");
                driver.setBlockRange(x, y + 1, z, y + 4, "minecraft:air");
                driver.setBlockLocal(x, y + 4, z, "minecraft:glass");
            }
        }
    }

    public static void generateBridge(ChunkDriver driver, BuildingInfo info) {
        int y = info.getCityGroundLevel();
        for (int x = 0; x < 16; x++) {
            for (int z = 4; z <= 11; z++) {
                driver.setBlockLocal(x, y, z, (z == 4 || z == 11) ? "minecraft:stone_brick_wall" : "minecraft:stone_bricks");
            }
        }
        if (info.profile.bridgeSupports) {
            generateSupportPillar(driver, 4, y - 1, 4);
            generateSupportPillar(driver, 11, y - 1, 11);
        }
    }

    public static void generateSupportPillar(ChunkDriver driver, int lx, int startY, int lz) {
        for (int y = startY; y >= driver.minY() + 1; y--) {
            String cur = driver.getBlockLocal(lx, y, lz);
            if (!"minecraft:air".equals(cur) && !"minecraft:water".equals(cur)) {
                break;
            }
            driver.setBlockLocal(lx, y, lz, "minecraft:cobblestone_wall");
        }
    }

    public static void generateStuff(ChunkDriver driver, BuildingInfo info) {
        Random rand = GenerationContext.current().random();
        if (!info.isCity || !info.hasBuilding) return;
        if (rand.nextFloat() < 0.25f) {
            int y = Math.min(driver.maxY() - 2, info.getCityGroundLevel() + 4);
            driver.setBlockLocal(2, y, 2, "minecraft:cobweb");
        }
    }

    public static void generateSphereShell(ChunkDriver driver, int chunkX, int chunkZ, LostCityProfile profile) {
        if (!profile.isSpheres() && !profile.isSpace()) return;
        int grid = profile.grid32 ? 32 : 16;
        int centerChunkX = Math.floorDiv(chunkX, grid) * grid + grid / 2;
        int centerChunkZ = Math.floorDiv(chunkZ, grid) * grid + grid / 2;
        int centerX = (centerChunkX << 4) + 8;
        int centerZ = (centerChunkZ << 4) + 8;
        int centerY = profile.groundLevel;
        int radius = 48;
        int rMin2 = (radius - 1) * (radius - 1);
        int rMax2 = radius * radius;
        int bx = chunkX << 4;
        int bz = chunkZ << 4;
        for (int lx = 0; lx < 16; lx++) {
            int dx = (bx + lx) - centerX;
            for (int lz = 0; lz < 16; lz++) {
                int dz = (bz + lz) - centerZ;
                int horiz2 = dx * dx + dz * dz;
                if (horiz2 > rMax2) continue;
                for (int y = Math.max(driver.minY(), centerY - radius); y < Math.min(driver.maxY(), centerY + radius); y++) {
                    int dy = y - centerY;
                    int d2 = horiz2 + dy * dy;
                    if (d2 >= rMin2 && d2 <= rMax2) {
                        driver.setBlockLocal(lx, y, lz, y >= centerY ? "minecraft:glass" : "minecraft:stone_bricks");
                    }
                }
            }
        }
    }
}
