/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

import mcjty.lostcities.paper.util.ThreadGuard;
import org.bukkit.World;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

/**
 * Thread-safe main-thread deferral queue for cross-chunk block fixes, loot chest binding,
 * and spawner placement. Replaces the non-thread-safe {@code HashMap} in the Fabric source.
 */
public final class GlobalTodo {

    private final ConcurrentHashMap<UUID, ConcurrentHashMap<Long, ConcurrentLinkedQueue<Consumer<World>>>> queues =
            new ConcurrentHashMap<>();
    private final AtomicInteger pendingCount = new AtomicInteger(0);

    public void enqueue(UUID worldId, int chunkX, int chunkZ, Consumer<World> task) {
        long key = ChunkCoord.pack(chunkX, chunkZ);
        queues.computeIfAbsent(worldId, id -> new ConcurrentHashMap<>())
                .computeIfAbsent(key, k -> new ConcurrentLinkedQueue<>())
                .add(task);
        pendingCount.incrementAndGet();
    }

    /**
     * Executes up to {@code maxBudget} deferred tasks on the main thread for chunks
     * that are already loaded (never triggering synchronous chunk loads).
     */
    public int drainForWorld(World world, int maxBudget) {
        ThreadGuard.requireMainThread("GlobalTodo.drainForWorld");
        ConcurrentHashMap<Long, ConcurrentLinkedQueue<Consumer<World>>> worldQueues = queues.get(world.getUID());
        if (worldQueues == null || worldQueues.isEmpty()) {
            return 0;
        }
        int executed = 0;
        for (Map.Entry<Long, ConcurrentLinkedQueue<Consumer<World>>> entry : worldQueues.entrySet()) {
            if (executed >= maxBudget) {
                break;
            }
            long packed = entry.getKey();
            int cx = (int) (packed >> 32);
            int cz = (int) packed;
            if (!world.isChunkLoaded(cx, cz)) {
                continue;
            }
            ConcurrentLinkedQueue<Consumer<World>> q = entry.getValue();
            Consumer<World> task;
            while (executed < maxBudget && (task = q.poll()) != null) {
                pendingCount.decrementAndGet();
                task.accept(world);
                executed++;
            }
            if (q.isEmpty()) {
                worldQueues.remove(packed, q);
            }
        }
        return executed;
    }

    public void clearWorld(UUID worldId) {
        ConcurrentHashMap<Long, ConcurrentLinkedQueue<Consumer<World>>> removed = queues.remove(worldId);
        if (removed != null) {
            int sub = 0;
            for (ConcurrentLinkedQueue<Consumer<World>> q : removed.values()) {
                sub += q.size();
            }
            pendingCount.addAndGet(-sub);
        }
    }

    public void clearAll() {
        queues.clear();
        pendingCount.set(0);
    }

    public int pendingCount() {
        return Math.max(0, pendingCount.get());
    }
}
