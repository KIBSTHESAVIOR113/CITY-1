/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

import mcjty.lostcities.paper.util.DeterministicRandom;

import java.util.Random;

/**
 * Thread-local per-chunk scratch state ensuring zero shared mutable RNG or buffers
 * across Paper async worldgen worker threads (Invariants #3, #4, #5).
 */
public final class GenerationContext {

    private static final ThreadLocal<GenerationContext> CURRENT = new ThreadLocal<>();
    private static final ThreadLocal<GenerationContext> FALLBACK =
            ThreadLocal.withInitial(() -> new GenerationContext(123456789));

    private int paletteSeed;
    private final Random random = new Random(0L);
    private final ChunkDriver driver = new ChunkDriver();
    private char streetChar = ' ';

    private GenerationContext(int paletteSeed) {
        this.paletteSeed = paletteSeed;
    }

    public static Scope open(long worldSeed, String dimensionId, int chunkX, int chunkZ) {
        GenerationContext prev = CURRENT.get();
        long mixed = DeterministicRandom.mixChunkSeed(worldSeed, dimensionId, chunkX, chunkZ);
        GenerationContext ctx = new GenerationContext((int) (mixed ^ (mixed >>> 32)));
        ctx.random.setSeed(mixed);
        CURRENT.set(ctx);
        return new Scope(prev);
    }

    public static GenerationContext current() {
        GenerationContext ctx = CURRENT.get();
        if (ctx == null) {
            throw new IllegalStateException("LostCities GenerationContext is not active on thread " + Thread.currentThread().getName());
        }
        return ctx;
    }

    /**
     * Exact LCG port of {@code GenerationContext.nextPaletteIndex()} (Invariant #4).
     */
    public static int nextPaletteIndex() {
        GenerationContext ctx = CURRENT.get();
        return (ctx == null ? FALLBACK.get() : ctx).next128();
    }

    private int next128() {
        paletteSeed = 214013 * paletteSeed + 2531011;
        return (paletteSeed >> 16) & 0x7f;
    }

    public Random random() { return random; }
    public ChunkDriver driver() { return driver; }
    public char streetChar() { return streetChar; }
    public void setStreetChar(char streetChar) { this.streetChar = streetChar; }

    public void reseedForDamage(int chunkX, int chunkZ) {
        random.setSeed(DeterministicRandom.damageReseed(chunkX, chunkZ));
    }

    public static final class Scope implements AutoCloseable {
        private final GenerationContext previous;
        private boolean closed;

        private Scope(GenerationContext previous) {
            this.previous = previous;
        }

        @Override
        public void close() {
            if (closed) return;
            closed = true;
            if (previous == null) {
                CURRENT.remove();
            } else {
                CURRENT.set(previous);
            }
        }
    }
}
