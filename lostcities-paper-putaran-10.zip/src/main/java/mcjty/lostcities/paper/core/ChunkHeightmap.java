/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

/**
 * Compact 16x16 terrain heightmap cached per chunk with min/max/average summaries.
 */
public final class ChunkHeightmap {

    private final short[] heights = new short[256];
    private int minHeight = Integer.MAX_VALUE;
    private int maxHeight = Integer.MIN_VALUE;
    private int avgHeight;

    public void set(int x, int z, int y) {
        int clamped = Math.max(Short.MIN_VALUE, Math.min(Short.MAX_VALUE, y));
        heights[(x & 15) * 16 + (z & 15)] = (short) clamped;
    }

    public void finish() {
        int sum = 0;
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        for (short h : heights) {
            if (h < min) min = h;
            if (h > max) max = h;
            sum += h;
        }
        this.minHeight = min;
        this.maxHeight = max;
        this.avgHeight = sum / 256;
    }

    public int getHeight(int x, int z) {
        return heights[(x & 15) * 16 + (z & 15)];
    }

    public int getMinimumHeight() { return minHeight; }
    public int getMaximumHeight() { return maxHeight; }
    public int getAverageHeight() { return avgHeight; }
    public int getHeight() { return avgHeight; }
}
