/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

import mcjty.lostcities.paper.assets.AssetModels;
import mcjty.lostcities.paper.assets.AssetRegistry;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Compiled character-to-block lookup table built from layered {@link AssetModels.PaletteAsset}
 * and {@link AssetModels.VariantAsset} definitions. Uses {@link GenerationContext#nextPaletteIndex()}
 * (Invariant #4) for deterministic randomized block selection.
 */
public final class CompiledPalette {

    public record Entry(String[] table128, String lootCondition, String mobCondition, boolean isTorch) {
        public String sample() {
            if (table128 == null || table128.length == 0) {
                return "minecraft:air";
            }
            if (table128.length == 1) {
                return table128[0];
            }
            return table128[GenerationContext.nextPaletteIndex() % table128.length];
        }
    }

    private final Map<Character, Entry> entries = new LinkedHashMap<>();

    public CompiledPalette(AssetRegistry registry, List<String> paletteNames) {
        for (String name : paletteNames) {
            AssetModels.PaletteAsset palette = registry.getPalette(name);
            if (palette == null) continue;
            for (AssetModels.PaletteEntryModel e : palette.entries()) {
                entries.put(e.symbol(), compileEntry(registry, e));
            }
        }
        entries.putIfAbsent(' ', new Entry(new String[]{"minecraft:air"}, "", "", false));
    }

    private Entry compileEntry(AssetRegistry registry, AssetModels.PaletteEntryModel e) {
        if (!e.randomBlocks().isEmpty()) {
            return new Entry(expandWeighted(e.randomBlocks()), e.loot(), e.mob(), e.torch());
        }
        if (e.variant() != null && !e.variant().isBlank()) {
            AssetModels.VariantAsset v = registry.getVariant(e.variant());
            if (v != null && !v.blocks().isEmpty()) {
                return new Entry(expandWeighted(v.blocks()), e.loot(), e.mob(), e.torch());
            }
        }
        String blk = (e.block() == null || e.block().isBlank()) ? "minecraft:stone_bricks" : e.block();
        return new Entry(new String[]{blk}, e.loot(), e.mob(), e.torch());
    }

    private static String[] expandWeighted(List<AssetModels.WeightedBlock> list) {
        int totalWeight = 0;
        for (AssetModels.WeightedBlock wb : list) {
            totalWeight += Math.max(1, wb.weight());
        }
        List<String> expanded = new ArrayList<>(128);
        for (AssetModels.WeightedBlock wb : list) {
            int count = Math.max(1, Math.round((float) Math.max(1, wb.weight()) * 128.0f / totalWeight));
            for (int i = 0; i < count && expanded.size() < 128; i++) {
                expanded.add(wb.block());
            }
        }
        while (expanded.size() < 128 && !list.isEmpty()) {
            expanded.add(list.get(0).block());
        }
        return expanded.toArray(String[]::new);
    }

    public Entry getEntry(char c) {
        return entries.get(c);
    }

    public String getBlock(char c) {
        Entry e = entries.get(c);
        return e == null ? null : e.sample();
    }
}
