/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.core;

/**
 * 16x16 building part coordinate transformations (rotation and mirror).
 */
public enum Transform {
    ROTATE_NONE(0),
    ROTATE_90(90),
    ROTATE_180(180),
    ROTATE_270(270),
    MIRROR_X(0),
    MIRROR_Z(0);

    private final int degrees;

    Transform(int degrees) {
        this.degrees = degrees;
    }

    public int degrees() {
        return degrees;
    }

    public int mapX(int x, int z) {
        return switch (this) {
            case ROTATE_NONE -> x;
            case ROTATE_90 -> 15 - z;
            case ROTATE_180 -> 15 - x;
            case ROTATE_270 -> z;
            case MIRROR_X -> 15 - x;
            case MIRROR_Z -> x;
        };
    }

    public int mapZ(int x, int z) {
        return switch (this) {
            case ROTATE_NONE -> z;
            case ROTATE_90 -> x;
            case ROTATE_180 -> 15 - z;
            case ROTATE_270 -> 15 - x;
            case MIRROR_X -> z;
            case MIRROR_Z -> 15 - z;
        };
    }

    public static Transform fromIndex(int idx) {
        return switch (Math.floorMod(idx, 4)) {
            case 0 -> ROTATE_NONE;
            case 1 -> ROTATE_90;
            case 2 -> ROTATE_180;
            default -> ROTATE_270;
        };
    }
}
