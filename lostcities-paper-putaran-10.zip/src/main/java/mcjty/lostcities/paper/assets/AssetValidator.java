/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.assets;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Contextual validator reporting exact file and field names for malformed JSON assets.
 */
public final class AssetValidator {

    private AssetValidator() {
    }

    public static final class ValidationException extends RuntimeException {
        private final String fileContext;
        private final String fieldName;

        public ValidationException(String fileContext, String fieldName, String message) {
            super("Asset validation error in [" + fileContext + "] field '" + fieldName + "': " + message);
            this.fileContext = fileContext;
            this.fieldName = fieldName;
        }

        public String fileContext() { return fileContext; }
        public String fieldName() { return fieldName; }
    }

    public static int requirePositiveInt(JsonObject obj, String field, String fileCtx, int defaultValue) {
        if (!obj.has(field)) {
            return defaultValue;
        }
        JsonElement el = obj.get(field);
        if (!el.isJsonPrimitive()) {
            throw new ValidationException(fileCtx, field, "expected integer");
        }
        int val = el.getAsInt();
        if (val <= 0) {
            throw new ValidationException(fileCtx, field, "must be > 0, got " + val);
        }
        return val;
    }

    public static void requireArray(JsonObject obj, String field, String fileCtx) {
        if (!obj.has(field) || !obj.get(field).isJsonArray()) {
            throw new ValidationException(fileCtx, field, "missing or not a JSON array");
        }
    }

    /**
     * Performs cross-reference integrity checks across a loaded {@link AssetRegistry}
     * and returns non-fatal warnings for dangling references.
     */
    public static List<String> validateCrossReferences(AssetRegistry registry) {
        List<String> warnings = new ArrayList<>();
        for (AssetModels.MultiBuildingAsset mb : registry.multiBuildings().values()) {
            for (List<String> row : mb.buildings()) {
                for (String bName : row) {
                    if (bName != null && !bName.isBlank() && registry.getBuilding(bName) == null) {
                        warnings.add("MultiBuilding '" + mb.id() + "' references unknown building '" + bName + "'");
                    }
                }
            }
        }
        for (AssetModels.CityStyleAsset cs : registry.cityStyles().values()) {
            if (cs.style() != null && !cs.style().isBlank() && registry.getStyle(cs.style()) == null) {
                warnings.add("CityStyle '" + cs.id() + "' references unknown style '" + cs.style() + "'");
            }
            if (cs.inherit() != null && !cs.inherit().isBlank() && registry.getCityStyle(cs.inherit()) == null) {
                warnings.add("CityStyle '" + cs.id() + "' inherits unknown citystyle '" + cs.inherit() + "'");
            }
        }
        return warnings;
    }
}
