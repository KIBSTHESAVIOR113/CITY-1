/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.generator;

import mcjty.lostcities.paper.LostCitiesPlugin;
import mcjty.lostcities.paper.core.ChunkDriver;
import mcjty.lostcities.paper.core.GenerationContext;
import mcjty.lostcities.paper.core.gen.StructureGenerators;
import org.bukkit.generator.BlockPopulator;
import org.bukkit.generator.LimitedRegion;
import org.bukkit.generator.WorldInfo;
import org.jetbrains.annotations.NotNull;

import java.util.Random;

/**
 * Secondary {@link BlockPopulator} matching {@code LostCitySphereFeature} for sphere/space profiles.
 */
public final class LostCitiesSpherePopulator extends BlockPopulator {

    private final LostCitiesPlugin plugin;
    private final String profileName;

    public LostCitiesSpherePopulator(LostCitiesPlugin plugin, String profileName) {
        this.plugin = plugin;
        this.profileName = profileName;
    }

    @Override
    public void populate(@NotNull WorldInfo worldInfo, @NotNull Random random, int chunkX, int chunkZ, @NotNull LimitedRegion limitedRegion) {
        WorldDimensionState state = plugin.getOrCreateDimensionState(worldInfo, profileName);
        if (!state.profile().isSpheres() && !state.profile().isSpace()) {
            return;
        }
        try (GenerationContext.Scope ignored = GenerationContext.open(
                worldInfo.getSeed(), "lostcities:" + worldInfo.getName(), chunkX, chunkZ)) {
            ChunkDriver driver = GenerationContext.current().driver();
            driver.begin(new LimitedRegionSurface(worldInfo, limitedRegion), chunkX, chunkZ);
            StructureGenerators.generateSphereShell(driver, chunkX, chunkZ, state.profile());
            driver.flush();
        }
    }
}
