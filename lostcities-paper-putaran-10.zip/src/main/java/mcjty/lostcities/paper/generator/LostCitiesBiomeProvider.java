/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.generator;

import mcjty.lostcities.paper.compat.PaperApiAdapter;
import mcjty.lostcities.paper.config.BiomeSelectionStrategy;
import mcjty.lostcities.paper.util.DeterministicRandom;
import org.bukkit.block.Biome;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.WorldInfo;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Random;

/**
 * Thread-safe {@link BiomeProvider} supporting custom {@link BiomeSelectionStrategy}
 * overrides while delegating {@code ORIGINAL} mode to vanilla Overworld multi-noise.
 */
public final class LostCitiesBiomeProvider extends BiomeProvider {

    private final PaperApiAdapter apiAdapter;
    private final BiomeSelectionStrategy strategy;
    private final List<Biome> palette;

    public LostCitiesBiomeProvider(PaperApiAdapter apiAdapter, BiomeSelectionStrategy strategy) {
        this.apiAdapter = apiAdapter;
        this.strategy = strategy;
        this.palette = apiAdapter.getAvailableBiomes();
    }

    @Override
    public @NotNull Biome getBiome(@NotNull WorldInfo worldInfo, int x, int y, int z) {
        if (palette.isEmpty()) {
            return Biome.PLAINS;
        }
        int cell = strategy == BiomeSelectionStrategy.VARIED ? 64 : 128;
        int gx = Math.floorDiv(x, cell);
        int gz = Math.floorDiv(z, cell);
        Random r = DeterministicRandom.buildingRandom(gx, gz, worldInfo.getSeed() ^ 0x7f4a7c15L);
        return palette.get(r.nextInt(palette.size()));
    }

    @Override
    public @NotNull List<Biome> getBiomes(@NotNull WorldInfo worldInfo) {
        return palette;
    }
}
