/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.generator;

import mcjty.lostcities.paper.config.HighwayGenerationMode;
import mcjty.lostcities.paper.config.LostCityProfile;
import mcjty.lostcities.paper.config.PluginConfig;
import mcjty.lostcities.paper.core.LostCityTerrainFeature;
import mcjty.lostcities.paper.core.highway.HighwayPlanningService;
import mcjty.lostcities.paper.core.highway.HighwayStore;
import mcjty.lostcities.paper.core.highway.IntercityHighwayPlanner;
import mcjty.lostcities.paper.core.plan.ChunkPlanner;
import mcjty.lostcities.paper.core.street.HierarchicalStreetPlanner;
import mcjty.lostcities.paper.persistence.AtomicFileStore;

import java.io.IOException;
import java.nio.file.Path;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * Per-world runtime container holding all bounded caches, planners, and highway persistence.
 * Never retains a strong reference to Bukkit {@code World} or {@code Chunk} objects (Risk R-11).
 */
public final class WorldDimensionState implements AutoCloseable {

    private final UUID worldId;
    private final String worldName;
    private final long seed;
    private final LostCityProfile profile;
    private final ChunkPlanner chunkPlanner;
    private final LostCityTerrainFeature terrainFeature;
    private final HierarchicalStreetPlanner streetPlanner;
    private final HighwayStore highwayStore;
    private final HighwayPlanningService highwayService;

    public WorldDimensionState(UUID worldId, String worldName, long seed, LostCityProfile profile,
                               PluginConfig cfg, Path pluginDataDir, Logger logger) {
        this.worldId = worldId;
        this.worldName = worldName;
        this.seed = seed;
        this.profile = profile;
        String dimId = "lostcities:" + worldName;
        this.chunkPlanner = new ChunkPlanner(cfg.chunkPlanMaxEntries(), cfg.cacheTtlSeconds());
        this.terrainFeature = new LostCityTerrainFeature(seed, dimId, profile);
        this.streetPlanner = new HierarchicalStreetPlanner(seed, dimId, profile);

        if (profile.highwayGenerationMode == HighwayGenerationMode.INTERCITY_NETWORK_V1) {
            Path worldDataDir = pluginDataDir.resolve("data").resolve(worldId.toString());
            AtomicFileStore store = new AtomicFileStore(worldDataDir, cfg.maxJsonFileBytes(), logger);
            long sig = seed ^ (long) profile.getName().hashCode() * 31L ^ profile.highwayPlanningCellSize;
            this.highwayStore = new HighwayStore(store, sig);
            IntercityHighwayPlanner planner = new IntercityHighwayPlanner(seed, dimId, profile, highwayStore);
            this.highwayService = new HighwayPlanningService(
                    planner, cfg.highwayHubMaxEntries(), cfg.highwayDependencyMaxEntries(), cfg.highwayWorkerThreads());
        } else {
            this.highwayStore = null;
            this.highwayService = null;
        }
    }

    public UUID worldId() { return worldId; }
    public String worldName() { return worldName; }
    public long seed() { return seed; }
    public LostCityProfile profile() { return profile; }
    public ChunkPlanner chunkPlanner() { return chunkPlanner; }
    public LostCityTerrainFeature terrainFeature() { return terrainFeature; }
    public HierarchicalStreetPlanner streetPlanner() { return streetPlanner; }
    public HighwayPlanningService highwayService() { return highwayService; }

    public void flushPersistence(Logger logger) {
        if (highwayStore != null) {
            try {
                highwayStore.flushIfDirty();
            } catch (IOException ex) {
                logger.warning("Failed flushing highway persistence for world '" + worldName + "': " + ex.getMessage());
            }
        }
    }

    @Override
    public void close() {
        if (highwayService != null) {
            highwayService.close();
        }
        chunkPlanner.clear();
    }
}
