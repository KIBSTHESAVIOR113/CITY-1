/*
 * MIT License
 * Copyright (c) McJty (Original LostCities mod)
 * Paper 26.3 port contributors
 */
package mcjty.lostcities.paper.generator;

import mcjty.lostcities.paper.LostCitiesPlugin;
import mcjty.lostcities.paper.config.BiomeSelectionStrategy;
import mcjty.lostcities.paper.config.LostCityProfile;
import org.bukkit.World;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.BlockPopulator;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Paper 26.3 {@link ChunkGenerator} preserving vanilla noise/surface/caves and layering
 * LostCities cities, streets, highways, and spheres via {@link BlockPopulator}s (DEC-01).
 */
public final class LostCitiesChunkGenerator extends ChunkGenerator {

    private final LostCitiesPlugin plugin;
    private final String profileName;

    public LostCitiesChunkGenerator(LostCitiesPlugin plugin, String profileName) {
        this.plugin = plugin;
        this.profileName = profileName;
    }

    @Override
    public boolean shouldGenerateNoise() {
        return true;
    }

    @Override
    public boolean shouldGenerateSurface() {
        return true;
    }

    @Override
    public boolean shouldGenerateCaves() {
        return true;
    }

    @Override
    public boolean shouldGenerateDecorations() {
        return !plugin.getPluginConfig().suppressVanillaDecorationsInCities();
    }

    @Override
    public boolean shouldGenerateMobs() {
        return true;
    }

    @Override
    public boolean shouldGenerateStructures() {
        return true;
    }

    @Override
    public @Nullable BiomeProvider getDefaultBiomeProvider(@NotNull WorldInfo worldInfo) {
        LostCityProfile profile = plugin.resolveProfile(profileName);
        if (profile.biomeSelectionStrategy == BiomeSelectionStrategy.ORIGINAL) {
            return null; // Use vanilla Overworld multi_noise biome source
        }
        return new LostCitiesBiomeProvider(plugin.getApiAdapter(), profile.biomeSelectionStrategy);
    }

    @Override
    public @NotNull List<BlockPopulator> getDefaultPopulators(@NotNull World world) {
        return List.of(
                new LostCitiesBlockPopulator(plugin, profileName),
                new LostCitiesSpherePopulator(plugin, profileName)
        );
    }
}
