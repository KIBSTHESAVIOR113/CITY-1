# Audit Thread-Safety & State Bersama (Putaran 7)

| State Bersama / Cache | Lokasi | Mekanisme Pengaman | Referensi World/Chunk? |
|---|---|---|---|
| `assetRegistry` | `LostCitiesPlugin` | `AtomicReference<AssetRegistry>` (snapshot immutable) | Tidak |
| `profiles` | `LostCitiesPlugin` | `AtomicReference<Map<String, LostCityProfile>>` (unmodifiable) | Tidak |
| `pluginConfig` | `LostCitiesPlugin` | `AtomicReference<PluginConfig>` (record immutable) | Tidak |
| `dimensions` | `LostCitiesPlugin` | `ConcurrentHashMap<UUID, WorldDimensionState>` (dibersihkan di `WorldUnloadEvent` & `onDisable`) | Tidak (hanya `UUID`) |
| `GlobalTodo.queues` | `GlobalTodo` | `ConcurrentHashMap<UUID, ConcurrentHashMap<Long, ConcurrentLinkedQueue<Consumer<World>>>>` | Tidak (hanya `UUID` + `long`) |
| `ChunkPlanner.plans` & `cityLevels` | `ChunkPlanner` (per-world) | `BoundedCache` (ber-`ReentrantLock` + LRU + TTL) | Tidak |
| `ChunkPlan` stage locks | `ChunkPlan` | 3 `ReentrantLock` terpisah per tahap (`infrastructure`, `characteristics`, `chunk`) tanpa siklus | Tidak |
| `HighwayPlanningService` caches | `HighwayPlanningService` | 2 `BoundedFutureCache` (kapasitas dari `config.yml`) + pool daemon ditutup di `close()` | Tidak |
| `HighwayStore.hubs` | `HighwayStore` | `ReentrantLock` + `TreeMap` berurutan + `AtomicFileStore` | Tidak |
| `LimitedRegionSurface.BLOCK_DATA_CACHE` | `LimitedRegionSurface` | `BoundedCache<String, BlockData>(2048, 3600)` | Tidak |
| `GenerationContext.CURRENT` | `GenerationContext` | `ThreadLocal<GenerationContext>` ditutup via `try-with-resources` (`Scope.close()`) | Tidak |
| `Metrics` | `Metrics` | `AtomicInteger` + `LongAdder` lock-free | Tidak |
