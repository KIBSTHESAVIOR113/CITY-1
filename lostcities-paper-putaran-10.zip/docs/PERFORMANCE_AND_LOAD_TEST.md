# Audit Performa, Memori & Skenario Tes Beban (Putaran 9)

## 1. Status Cache Berbatas
Seluruh cache pada proyek memiliki batas kapasitas eksplisit dan dapat dikonfigurasi di `config.yml`:
- `ChunkPlanner.plans` & `cityLevels`: `caches.chunk-plan-max-entries` (default `4096`) + `caches.cache-ttl-seconds` (default `300`)
- `HighwayPlanningService.hubCache`: `caches.highway-hub-max-entries` (default `4096`)
- `HighwayPlanningService.routeCache`: `caches.highway-dependency-max-entries` (default `2048`)
- `LimitedRegionSurface.BLOCK_DATA_CACHE`: `2048` entri, TTL `3600` detik (diperbaiki pada Putaran 9 dari `ConcurrentHashMap` tanpa batas)

## 2. Metrik di `/lostcities stats`
- Total chunk digenerate (`chunks`)
- Rata-rata waktu generate chunk (`avg` ms)
- Persentil ke-95 (`p95` ms, jendela 1024 sampel terbaru)
- Ukuran antrean `GlobalTodo` (`todoQueue`)
- Jumlah dunia aktif & ringkasan seluruh 13 registry aset

## 3. Skenario Tes Beban (20 Pemain / Bot, 15 Menit)
1. Siapkan server Paper 26.3 (`-Xms2G -Xmx4G -XX:+UseG1GC`) dengan dunia `lostcity` (profil `default`, seed `12345`).
2. Hubungkan 20 klien/bot (`mineflayer` atau player terbang kreatif kecepatan 20 blok/dtk) menyebar ke 20 arah radial selama 15 menit.
3. Catat setiap 60 detik: `/lc stats`, `/tps`, penggunaan heap JVM (`jstat -gc <pid>`), dan `logs/latest.log`.

### Ambang Lulus
- **Stabilisasi Heap**: Heap pasca-GC tidak naik monoton selama menit ke-5 sampai menit ke-15 (selisih < 15% dari baseline menit ke-5).
- **Latensi Generate**: `p95` generate chunk < 25 ms; nol deadlock atau watchdog timeout.
- **Stabilitas Tick**: Nol pesan `"Can't keep up!"` yang disebabkan oleh task `GlobalTodo` plugin (kuota default 50 tugas/tick).
- **Integritas Log**: Nol `Exception` / `ConcurrentModificationException` dari paket `mcjty.lostcities.paper`.
